"""Gradient ledger: per-region (in/out-strip) gradient mass for l2 vs flow at
2k and 12k — total first-layer and sensor-column, raw and share-weighted."""
import numpy as np
import torch

import toyattr as T

data, ob = T.build_dataset(None, data_seed=0)
X, Y, W = data
Xt = torch.tensor(X, device=T.DEV); Yt = torch.tensor(Y, device=T.DEV)
ins = np.where(W)[0]; outs = np.where(~W)[0]
q = W.mean()
dv = T.DIMV


def region_grad(net, loss_name, idx, rng, nb=32):
    W1 = net.f[0].weight
    tot, sens = [], []
    for _ in range(nb):
        sub = idx[rng.randint(0, len(idx), 256)]
        xb, yb = Xt[sub], Yt[sub]
        if loss_name == "flow8":
            yn = (yb - net.ymu) / net.ysd
            eps = torch.randn_like(yn)
            tt = torch.rand(len(yn), 1, device=T.DEV)
            ytt = (1 - tt) * eps + tt * yn
            v = net.vel(xb, ytt, tt)
            l = ((v - (yn - eps)) ** 2).sum(dim=1).mean()
        else:
            pred, _ = net._fwd_norm(xb)
            ybn = (yb - net.yc) / net.ys
            l = ((pred - ybn) ** 2).sum(dim=1).mean()
        net.zero_grad(); l.backward()
        g = W1.grad.detach()
        tot.append(float(g.norm())); sens.append(float(g[:, dv:dv + 2].norm()))
    return np.mean(tot), np.mean(sens)


for arm in ("l2", "flow8"):
    for steps in (2000, 12000):
        net = T.train((data, ob), arm, seed=0, steps=steps)
        rng = np.random.RandomState(7)
        ti, si = region_grad(net, arm, ins, rng)
        to, so = region_grad(net, arm, outs, rng)
        wi = q * ti / (q * ti + (1 - q) * to)
        wsi = q * si / (q * si + (1 - q) * so)
        print(f"{arm} @{steps}: total-grad in/out {ti:.3f}/{to:.3f} (in-share sample-weighted {wi:.2f}) | "
              f"sensor-col in/out {si:.3f}/{so:.3f} (in-share {wsi:.2f})", flush=True)
