"""Visualize the redun (tactile-analog) battery: ID parity vs OOD collapse,
bias dose-response, T-share mediation, and the attr/redun double dissociation."""
import json
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
R = json.load(open(os.path.join(HERE, "redun_final.json")))
A = json.load(open(os.path.join(HERE, "attr_final.json")))
OUT = os.path.join(HERE, "redun_viz.png")

ARMS = ["l2", "hg", "ht", "oversamp", "mip", "fact", "gdrop", "tonly"]
LBL = {"l2": "L2", "hg": "hetero-G", "ht": "hetero-t", "oversamp": "oversample",
       "mip": "MIP", "fact": "fact+gate", "gdrop": "V-dropout", "tonly": "T-only\n(oracle)"}
COL = {"l2": "#d62728", "hg": "#ff9896", "ht": "#9467bd", "oversamp": "#8c564b",
       "mip": "#1f77b4", "fact": "#e377c2", "gdrop": "#2ca02c", "tonly": "#17becf"}


def sr8(cells):
    return np.array([c["SR"]["8"] if "8" in c["SR"] else c["SR"][8] for c in cells])


def ood(cells, key):
    return np.array([c["OOD"][key] for c in cells])


def tsh(cells):
    return np.array([c["T_share_endgame"] for c in cells])


fig, axes = plt.subplots(2, 2, figsize=(13.5, 10.5))

# --- A: ID vs OOD bars ------------------------------------------------------
ax = axes[0, 0]
x = np.arange(len(ARMS)); w = 0.27
for i, (key, name, c) in enumerate([("ID", "in-distribution", "0.35"),
                                    ("bias0.04", "OOD: vision bias 0.04", "#d62728"),
                                    ("occl0", "OOD: vision-fine occluded", "#1f77b4")]):
    vals = [sr8(R[a]).mean() if key == "ID" else ood(R[a], key).mean() for a in ARMS]
    errs = [sr8(R[a]).std() if key == "ID" else ood(R[a], key).std() for a in ARMS]
    ax.bar(x + (i - 1) * w, vals, w, yerr=errs, color=c, label=name,
           error_kw=dict(lw=0.8, capsize=2), edgecolor="white", linewidth=0.5)
ax.set_xticks(x); ax.set_xticklabels([LBL[a] for a in ARMS], fontsize=8)
ax.set_ylabel("success rate (AS=8)")
ax.set_ylim(0, 1.12)
ax.legend(fontsize=8, loc="upper left", ncol=1)
ax.set_title("A. Every monolithic arm: perfect in-distribution, dead under\n"
             "vision corruption. Only V-dropout (and the T-only oracle) survive")

# --- B: bias dose-response --------------------------------------------------
ax = axes[0, 1]
doses = [0.0, 0.02, 0.04, 0.08]
for a in ARMS:
    ys = [sr8(R[a]).mean()] + [ood(R[a], f"bias{d:g}").mean() for d in doses[1:]]
    es = [sr8(R[a]).std()] + [ood(R[a], f"bias{d:g}").std() for d in doses[1:]]
    lw = 2.2 if a in ("gdrop", "tonly", "l2") else 1.2
    ax.errorbar(doses, ys, yerr=es, color=COL[a], lw=lw, marker="o", ms=4,
                capsize=2, label=LBL[a].replace("\n", " "))
ax.axvline(0.02, color="gray", ls=":", lw=0.8)
ax.text(0.0205, 0.03, "tol = 0.02\n(bias > tol\n= guaranteed miss\nfor V-committed)", fontsize=7, color="gray")
ax.set_xlabel("vision-fine calibration bias |b| (T channel stays truthful)")
ax.set_ylabel("success rate (AS=8)")
ax.set_title("B. Dose-response: V-committed policies fail once the bias\n"
             "exceeds tolerance; T-keeping policies are unaffected")
ax.legend(fontsize=7.5, ncol=2, loc="center right")
ax.set_ylim(-0.03, 1.05)

# --- C: T-share mediation scatter ------------------------------------------
ax = axes[1, 0]
allx, ally = [], []
for a in ARMS:
    xs, ys = tsh(R[a]), ood(R[a], "bias0.04")
    allx += list(xs); ally += list(ys)
    ax.scatter(xs, ys, s=26, color=COL[a], label=LBL[a].replace("\n", " "),
               alpha=0.85, edgecolor="white", linewidth=0.4)
r = np.corrcoef(allx, ally)[0, 1]
ax.set_xlabel("endgame T-share (Jacobian mass on the T channel, in-distribution)")
ax.set_ylabel("OOD success rate (bias 0.04)")
ax.set_title(f"C. Mediation: attribution measured IN-distribution predicts\n"
             f"OOD success (r = {r:+.2f}, n = 80 runs)")
ax.legend(fontsize=7.5, loc="center left")
ax.set_xlim(-0.03, 1.0); ax.set_ylim(-0.05, 1.05)

# --- D: double dissociation vs attr config ---------------------------------
ax = axes[1, 1]
show = ["l2", "ht", "gdrop"]
attr_sr = {a: sr8(A[a]) for a in show}
redun_sr = {a: ood(R[a], "bias0.04") for a in show}
x = np.arange(2); w = 0.24
for i, a in enumerate(show):
    vals = [attr_sr[a].mean(), redun_sr[a].mean()]
    errs = [attr_sr[a].std(), redun_sr[a].std()]
    ax.bar(x + (i - 1) * w, vals, w, yerr=errs, color=COL[a],
           label=LBL[a].replace("\n", " "), error_kw=dict(lw=0.8, capsize=2))
    for xi, v in zip(x, vals):
        ax.text(xi + (i - 1) * w, v + 0.04, f"{v:.2f}", ha="center", fontsize=8)
ax.set_xticks(x)
ax.set_xticklabels(["noise-floor starvation\n(attr config, ID SR)",
                    "redundancy capture\n(redun config, OOD SR @ bias 0.04)"], fontsize=9)
ax.set_ylabel("success rate")
ax.set_ylim(0, 1.15)
ax.legend(fontsize=8, loc="upper right")
ax.set_title("D. Double dissociation: the likelihood cure (hetero-t) fixes only\n"
             "noise-starvation; the input cure (V-dropout) fixes only redundancy capture")

for a_ in axes.flat:
    a_.grid(alpha=0.25, lw=0.4, axis="y")
fig.suptitle("Tactile-analog toy (config redun): a redundant-on-support channel is ignored at zero in-distribution cost\n"
             "and full OOD cost — and only per-modality training pressure (dropout / budget isolation) keeps it engaged",
             y=0.995, fontsize=11)
fig.tight_layout(rect=(0, 0, 1, 0.965))
fig.savefig(OUT, dpi=150)
print("saved", OUT)
