"""Formation-window probe: sigma ratio (endgame/reach), residual ratio, and
T-share vs training step for hg vs l2."""
import numpy as np
import torch

import toyattr as T

data, ob = T.build_dataset(None, data_seed=0)
X, Y, W = data
Xt = torch.tensor(X, device=T.DEV); Yt = torch.tensor(Y, device=T.DEV)
e = torch.tensor(W, device=T.DEV)
CKPTS = {250, 500, 1000, 2000, 4000, 8000, 12000}

for loss in ("hg", "l2"):
    torch.manual_seed(0)
    net = T.Net(X.shape[1]).to(T.DEV)
    opt = torch.optim.Adam(net.parameters(), lr=1e-3)
    rng = np.random.RandomState(0)
    for it in range(1, 12001):
        idx = rng.randint(0, len(Xt), 256)
        xb, yb = Xt[idx], Yt[idx]
        pred, sraw = net(xb)
        r2 = ((pred - yb) ** 2).sum(dim=1)
        if loss == "hg":
            sig = torch.nn.functional.softplus(sraw) + 1e-3
            l = (0.5 * r2 / sig ** 2 + (2 * T.H) * torch.log(sig)).mean()
        else:
            l = r2.mean()
        opt.zero_grad(); l.backward(); opt.step()
        if it in CKPTS:
            with torch.no_grad():
                p, sr = net(Xt)
                sig = torch.nn.functional.softplus(sr) + 1e-3
                rms = (((p - Yt) ** 2).sum(1) / (2 * T.H)).sqrt()
                w = 1.0 / sig ** 2
            sh = T.group_share(net, X, W)
            print(f"{loss} @{it:5d}: sig e/r {sig[e].mean():.4f}/{sig[~e].mean():.4f} "
                  f"(ratio {sig[e].mean()/sig[~e].mean():.2f}) | rms e/r {rms[e].mean():.4f}/{rms[~e].mean():.4f} | "
                  f"endgame weight share {(w[e].sum()/w.sum()):.3f} (count {e.float().mean():.3f}) | "
                  f"T-share {sh:.3f}", flush=True)
