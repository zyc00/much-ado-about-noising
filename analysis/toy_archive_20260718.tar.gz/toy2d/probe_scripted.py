"""Scripted-data analog: deterministic field (fully position-explainable),
small area, zero label noise. Deployment axis = state-perturbation dose
(interpolation robustness). Measures F-share, cancel gain, Jacobian norm
(contraction), SR vs kick dose."""
import numpy as np
import torch

import toyattr as T

data, ob = T.build_dataset(None, data_seed=0)
X, Y, W = data


def fshare_cgain(net):
    xs = torch.tensor(X[W][:256], device=T.DEV, requires_grad=True)
    pred = net.chunk_from_obs(xs)
    gT = gV = 0.0
    for k in range(0, 2 * T.H, 4):
        g = torch.autograd.grad(pred[:, k].sum(), xs, retain_graph=True)[0]
        gV += float((g[:, :T.DIMV] ** 2).sum()); gT += float((g[:, T.DIMV:] ** 2).sum())
    a1x = net.chunk_from_obs(xs)[:, 0]
    g = torch.autograd.grad(a1x.sum(), xs)[0]
    return gT / (gT + gV + 1e-12), float(g[:, 12].mean())


def jnorm(net):
    xs = torch.tensor(X[W][:128], device=T.DEV, requires_grad=True)
    pred = net.chunk_from_obs(xs)
    tot = 0.0
    for k in range(0, 2 * T.H, 4):
        g = torch.autograd.grad(pred[:, k].sum(), xs, retain_graph=True)[0]
        tot += float((g ** 2).sum(dim=1).mean())
    return tot ** 0.5


def rollout_kick(policy, dose, n_ep=100, seed=999):
    rng = np.random.RandomState(seed)
    succ = 0
    for _ in range(n_ep):
        g = rng.uniform([-0.3, -0.3], [0.3, 0.3])
        p = np.array([0.0, float(T._os.environ.get("Y0", "1.4"))]) + 0.05 * rng.randn(2)
        kicks = set(rng.randint(20, 160, 3))
        held, ok = 0, False
        for step in range(220):
            f = T.field(p, g, np.zeros(2))
            fs = f + T.FNOISE * rng.randn(2)
            a = policy(p, g, fs, rng)
            p = p + np.clip(a, -T.DCLIP, T.DCLIP) + f
            if step in kicks:
                v = rng.randn(2); p = p + dose * v / (np.linalg.norm(v) + 1e-9)
                held = 0
            held = held + 1 if np.linalg.norm(p - g) < T.TOL else 0
            if held >= T.TS_HOLD:
                ok = True; break
        succ += int(ok)
    return succ / n_ep


def net_policy(net):
    def pol(p, g, fs, rng):
        o = torch.tensor(ob.obs(p, g, np.zeros(2), rng, None, f=fs)[None], device=T.DEV)
        with torch.no_grad():
            return net(o)[0].reshape(T.H, 2).cpu().numpy()[0]
    return pol


def expert_policy(p, g, fs, rng):
    return np.clip(0.25 * (g - p), -0.15, 0.15) - fs


import os as _o
esr = [rollout_kick(expert_policy, d) for d in (0.0, 0.08, 0.15, 0.25)]
print(f"expert: SR impulse 0/.05/.10/.15 = {esr[0]:.2f}/{esr[1]:.2f}/{esr[2]:.2f}/{esr[3]:.2f}", flush=True)
for arm in ("l2", "ht", "mip", "flow8"):
    net = T.train((data, ob), arm, seed=0, steps=12000)
    fs, cg = fshare_cgain(net)
    jn = jnorm(net)
    srs = [rollout_kick(net_policy(net), d) for d in (0.0, 0.08, 0.15, 0.25)]
    print(f"{arm:6s}: F-share {fs:.2f} cgain {cg:+.2f} |J| {jn:.2f} | "
          f"SR impulse 0/.08/.15/.25 = {srs[0]:.2f}/{srs[1]:.2f}/{srs[2]:.2f}/{srs[3]:.2f}", flush=True)
