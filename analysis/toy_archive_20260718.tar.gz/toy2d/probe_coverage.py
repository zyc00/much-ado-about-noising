"""Coverage dose-response: SR (no kicks) vs data-generation EXNOISE for l2 vs
mip, 2 seeds — the toy version of the pristine-demo scaling law."""
import numpy as np
import torch

import toyattr as T


def rollout(net, ob, n_ep=100, seed=999):
    rng = np.random.RandomState(seed)
    succ = 0
    for _ in range(n_ep):
        g = rng.uniform([-0.3, -0.3], [0.3, 0.3])
        p = np.array([0.0, float(T._os.environ.get("Y0", "1.4"))]) + 0.05 * rng.randn(2)
        held, ok = 0, False
        for step in range(200):
            f = T.field(p, g, np.zeros(2))
            fs = f + T.FNOISE * rng.randn(2)
            o = torch.tensor(ob.obs(p, g, np.zeros(2), rng, None, f=fs)[None], device=T.DEV)
            with torch.no_grad():
                a = net(o)[0].reshape(T.H, 2).cpu().numpy()[0]
            p = p + np.clip(a, -T.DCLIP, T.DCLIP) + f
            held = held + 1 if np.linalg.norm(p - g) < T.TOL else 0
            if held >= T.TS_HOLD:
                ok = True; break
        succ += int(ok)
    return succ / n_ep


import os
for ex in ("0.003", "0.005", "0.008", "0.012", "0.02"):
    os.environ["EXNOISE"] = ex
    data, ob = T.build_dataset(None, data_seed=0)
    for arm in ("l2", "mip"):
        srs = []
        for seed in (0, 1):
            net = T.train((data, ob), arm, seed=seed, steps=12000)
            srs.append(rollout(net, ob))
        print(f"EXNOISE={ex} {arm:4s}: SR {np.mean(srs):.2f} (seeds {srs[0]:.2f}/{srs[1]:.2f})", flush=True)
