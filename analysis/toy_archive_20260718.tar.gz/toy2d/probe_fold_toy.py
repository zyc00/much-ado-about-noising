"""Direct collapse probe: pairs of endgame states identical except for the
fine offset delta (they REQUIRE different actions). Measures (a) feature-
space separation per unit input change for the T-only swap vs a matched-
norm V-only (coarse position) change, (b) realized action separation as a
fraction of the oracle separation 0.25*|d1-d2|. sep->0 = fold."""
import numpy as np
import torch

import toyattr as T

data, ob = T.build_dataset(None, data_seed=0)
X = data[0]
rng = np.random.RandomState(5)
pairs = []
for _ in range(128):
    g = rng.uniform([-0.3, -0.3], [0.3, 0.3])
    p = g + rng.uniform(0.02, 0.10) * T._unit(rng)
    d1 = rng.uniform(0.03, 0.08) * T._unit(rng)
    d2 = rng.uniform(0.03, 0.08) * T._unit(rng)
    o1 = ob.obs(p, g, d1, np.random.RandomState(7))
    o2 = o1.copy(); o2[16:18] = (g + d2 - p) + 0.005 * np.random.RandomState(8).randn(2)
    dx_t = np.linalg.norm(o2 - o1)
    pv = p + np.linalg.norm(d1 - d2) * T._unit(rng)
    o3 = ob.obs(pv, g, d1, np.random.RandomState(7)); o3[16:18] = o1[16:18]
    pairs.append((o1, o2, o3, dx_t, np.linalg.norm(o3 - o1), np.linalg.norm(d1 - d2)))

O1 = torch.tensor(np.array([p[0] for p in pairs]), device=T.DEV)
O2 = torch.tensor(np.array([p[1] for p in pairs]), device=T.DEV)
O3 = torch.tensor(np.array([p[2] for p in pairs]), device=T.DEV)
dxt = np.array([p[3] for p in pairs]); dxv = np.array([p[4] for p in pairs])
dd = np.array([p[5] for p in pairs])

for loss in ("l2", "hg", "hgw", "ht", "mip", "fact"):
    net = T.train((data, ob), loss, seed=0, steps=12000)
    with torch.no_grad():
        z1, z2, z3 = net.features(O1), net.features(O2), net.features(O3)
        a1 = net.chunk_from_obs(O1).reshape(-1, T.H, 2)[:, 0]
        a2 = net.chunk_from_obs(O2).reshape(-1, T.H, 2)[:, 0]
    st = (z2 - z1).norm(dim=1).cpu().numpy() / dxt
    sv = (z3 - z1).norm(dim=1).cpu().numpy() / dxv
    da = (a2 - a1).norm(dim=1).cpu().numpy()
    sep = da / (T.KSERVO * dd)
    print(f"{loss:5s}: feat sens T-swap/V-move = {st.mean():.2f}/{sv.mean():.2f} "
          f"(ratio {st.mean()/sv.mean():.2f}) | action sep frac = {sep.mean():.2f} "
          f"(p10 {np.percentile(sep,10):.2f})", flush=True)
