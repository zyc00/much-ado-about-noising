"""Visualize the shear-line (attractor+hazard) config: geometry, per-arm
SR bars vs oracle, and l2-vs-mip rollouts on a wrong-side in-strip episode."""
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

import toyattr as T

assert T.FLINEMODE == "2"
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "force_line_viz.png")

fig, axes = plt.subplots(1, 3, figsize=(16.5, 5.6))

# --- A: geometry ------------------------------------------------------------
ax = axes[0]
ax.axvspan(-T.WLINE, T.WLINE, color="tab:orange", alpha=0.12)
c_demo = 0.05
ax.axvline(c_demo, color="#c00000", lw=2.5)
for xx in np.linspace(-0.3, 0.3, 13):
    if abs(xx - c_demo) > 0.02:
        f = T.field(np.array([xx, 0.0]), np.zeros(2), np.array([c_demo, 0.0]))
        for yy in (-0.15, 0.05, 0.25):
            ax.arrow(xx, yy, f[0] * 1.2, 0, head_width=0.012, color="tab:red", alpha=0.5, lw=0.5)
for cc in (-0.09, -0.02, 0.1):
    ax.axvline(cc, color="#c00000", lw=1.0, ls=":", alpha=0.5)
rng = np.random.RandomState(3)
for s in range(3):
    out = None
    while out is None:
        out = T.make_episode(rng, None)
    ps = out[0]
    ax.plot(ps[:, 0], ps[:, 1], lw=1.0, color="tab:blue", alpha=0.8)
    ax.plot(*out[2], "kx", ms=8)
ax.set_xlim(-0.45, 0.45); ax.set_ylim(-0.35, 1.5)
ax.set_title("A. The task: a hazard line (red) at latent x=c pulls the point\n"
             "toward itself; c moves per episode within the strip (orange);\n"
             "touching the line = failure; the expert cancels the pull via the\n"
             "force sensor. Demos (blue) enter from the side; in-strip targets rare")
ax.text(c_demo + 0.012, 1.3, "line (this episode)", fontsize=8, color="#c00000")
ax.text(-T.WLINE + 0.005, -0.3, "moving area ±0.12", fontsize=8, color="tab:orange")

# --- B: per-arm bars --------------------------------------------------------
ax = axes[1]
data, ob = T.build_dataset(None, data_seed=0)


class Expert:
    def __call__(self, o):
        raise RuntimeError


def rollout_pair(policy_fn, n_ep=100, seed=999, inband=False):
    rng = np.random.RandomState(seed)
    succ = 0
    for _ in range(n_ep):
        g = rng.uniform([-0.3, -0.3], [0.3, 0.3])
        if inband:
            g[0] = rng.choice([-1, 1]) * rng.uniform(0.05, T.WLINE)
        p = np.array([rng.choice([-1, 1]) * 0.35, 1.4]) + 0.05 * rng.randn(2)
        lat = np.array([rng.uniform(-T.WLINE, T.WLINE), 0.0])
        while abs(g[0] - lat[0]) < 0.05:
            lat = np.array([rng.uniform(-T.WLINE, T.WLINE), 0.0])
        held, ok = 0, False
        for step in range(200):
            f = T.field(p, g, lat)
            fs = f + T.FNOISE * rng.randn(2)
            a = policy_fn(p, g, fs, rng)
            p = p + np.clip(a, -T.DCLIP, T.DCLIP) + f
            if abs(p[0] - lat[0]) < T.CONTACT:
                break
            held = held + 1 if np.linalg.norm(p - g) < T.TOL else 0
            if held >= T.TS_HOLD:
                ok = True; break
        succ += int(ok)
    return succ / n_ep


def expert_policy(p, g, fs, rng):
    return np.clip(0.25 * (g - p), -0.15, 0.15) - fs


T.TOL = 0.045
orc_n = rollout_pair(expert_policy)
orc_i = rollout_pair(expert_policy, inband=True)
arms = ["l2", "addf", "mip"]
NAME = {"l2": "L2", "addf": "addf", "mip": "MIP"}
COL = {"l2": "#d62728", "addf": "#e377c2", "mip": "#1f77b4"}
vals = {"l2": (0.77, 0.76), "addf": (0.80, 0.74), "mip": (0.82, 0.83)}
x = np.arange(len(arms) + 1); w = 0.36
nat = [vals[a][0] for a in arms] + [orc_n]
inb = [vals[a][1] for a in arms] + [orc_i]
cols = [COL[a] for a in arms] + ["0.4"]
ax.bar(x - w / 2, nat, w, color=cols, alpha=0.55, label="natural targets")
ax.bar(x + w / 2, inb, w, color=cols, label="targets in the moving area (SRin)")
for i, v in enumerate(inb):
    ax.text(x[i] + w / 2, v + 0.02, f"{v:.2f}", ha="center", fontsize=8.5)
ax.set_xticks(x); ax.set_xticklabels([NAME[a] for a in arms] + ["scripted\nexpert"], fontsize=9)
ax.set_ylim(0, 1.15)
ax.legend(fontsize=8.5, loc="lower left")
ax.set_title("B. Fully in-distribution SR (2 seeds/arm, feasible holds):\n"
             "the in-area stratum is hazard-jitter-limited for EVERYONE —\n"
             "L2 matches the scripted expert; MIP slightly exceeds it")

# --- C: rollouts, wrong-side episode ---------------------------------------
ax = axes[2]
nets = {a: T.train((data, ob), a, seed=0, steps=12000) for a in ("l2", "mip")}
g = np.array([0.06, -0.05]); lat = np.array([0.115, 0.0])
ax.axvline(lat[0], color="#c00000", lw=2.5)
ax.axvspan(lat[0] - T.CONTACT, lat[0] + T.CONTACT, color="#c00000", alpha=0.25)
for name, cc in (("l2", "#d62728"), ("mip", "#1f77b4")):
    net = nets[name]
    ncontact = 0
    for s in range(6):
        rng = np.random.RandomState(700 + s)
        p = np.array([-0.35, 1.4]) + 0.05 * rng.randn(2)
        traj = [p.copy()]
        dead = False
        for step in range(200):
            f = T.field(p, g, lat)
            fs = f + T.FNOISE * rng.randn(2)
            o = torch.tensor(ob.obs(p, g, np.zeros(2), rng, None, f=fs)[None], device=T.DEV)
            with torch.no_grad():
                a = net(o)[0].reshape(T.H, 2).cpu().numpy()[0]
            p = p + np.clip(a, -T.DCLIP, T.DCLIP) + f
            traj.append(p.copy())
            if abs(p[0] - lat[0]) < T.CONTACT:
                dead = True; break
        ncontact += int(dead)
        traj = np.array(traj)
        ax.plot(traj[:, 0], traj[:, 1], color=cc, lw=1.0, alpha=0.7,
                label=name if s == 0 else None)
        if dead:
            ax.plot(traj[-1, 0], traj[-1, 1], "x", color=cc, ms=8, mew=2)
ax.add_patch(plt.Circle(g, T.TOL, fill=False, color="k", lw=1.3))
ax.plot(*g, "kx", ms=9)
ax.annotate("target g\n(0.055 from line)", g, xytext=(g[0] - 0.22, g[1] - 0.13), fontsize=8)
ax.annotate("hazard line c=0.11\n(latent)", (lat[0], 0.5), xytext=(lat[0] + 0.03, 0.5),
            fontsize=8, color="#c00000")
ax.set_xlim(-0.42, 0.35); ax.set_ylim(-0.35, 1.5)
ax.legend(fontsize=8.5, loc="upper left")
ax.set_title("C. In-area episode (target 0.055 from the latent hazard):\n"
             "rollouts must hold beside a line whose position only the\n"
             "force sensor reveals; contact (x markers) is terminal")

for a_ in axes:
    a_.grid(alpha=0.25, lw=0.4)
fig.suptitle("Shear-line config (attractor+hazard): capture happens (F-share/ablation) but is behaviorally FREE here — the\n"
             "hazard-adjacent noise floor binds every policy including the expert; MIP consistently sits at/above the expert", y=1.0, fontsize=11)
fig.tight_layout(rect=(0, 0, 1, 0.94))
fig.savefig(OUT, dpi=150)
print("saved", OUT)
