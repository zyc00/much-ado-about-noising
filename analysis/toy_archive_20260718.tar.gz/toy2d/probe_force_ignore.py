"""Behavioral test: does l2 ignore the force sensor? Evals: normal | sensor
zeroed | sensor scrambled | field shifted at deployment (sensor truthful)."""
import numpy as np
import torch

import toyattr as T

assert T.CONFIG == "force"


def rollout(net, ob, n_ep=100, AS=1, seed=999, sensor="true", shift=0.0, inband=False):
    rng = np.random.RandomState(seed)
    succ = 0
    sv = np.array([shift, 0.0])
    for _ in range(n_ep):
        g = rng.uniform([-0.3, -0.3], [0.3, 0.3])
        if inband and T.FLINE:
            g[0] = rng.choice([-1, 1]) * rng.uniform(0.05, T.WLINE)
        p = (np.array([rng.choice([-1, 1]) * 0.35, 1.4]) if T.FLINE
             else np.array([0.0, 1.4])) + 0.05 * rng.randn(2)
        lat = (np.array([rng.uniform(-T.WLINE, T.WLINE), 0.0]) if T.FLINE
               else np.zeros(2))
        while T.FLINEMODE == "2" and abs(g[0] - lat[0]) < 0.05:
            lat = np.array([rng.uniform(-T.WLINE, T.WLINE), 0.0])
        held = 0; ok = False
        for step in range(0, 200, AS):
            f_true = T.field(p, g, lat)
            f_app = f_true + (sv if np.linalg.norm(p - g) < T.RF else 0.0)
            if sensor == "true":
                fs = f_app
            elif sensor == "zero":
                fs = np.zeros(2)
            else:
                fs = 0.06 * rng.randn(2)
            o = torch.tensor(ob.obs(p, g, np.zeros(2), rng, None, f=fs)[None], device=T.DEV)
            with torch.no_grad():
                chunk = net(o)[0].reshape(T.H, 2).cpu().numpy()
            for a in chunk[:AS]:
                f_true = T.field(p, g, lat)
                f_app = f_true + (sv if np.linalg.norm(p - g) < T.RF else 0.0)
                p = p + np.clip(a, -T.DCLIP, T.DCLIP) + f_app
                if T.FLINEMODE == "2" and abs(p[0] - lat[0]) < T.CONTACT:
                    ok = False; held = -10**6; break
                held = held + 1 if np.linalg.norm(p - g) < T.TOL else 0
                if held >= T.TS_HOLD:
                    ok = True; break
            if ok or held < -1:
                break
        succ += int(ok)
    return succ / n_ep


def rollout_dose(net, ob, n_ep=100, AS=1, seed=999, smax=0.05):
    rng = np.random.RandomState(seed)
    succ, parks = 0, []
    for _ in range(n_ep):
        g = rng.uniform([-0.3, -0.3], [0.3, 0.3])
        p = (np.array([rng.choice([-1, 1]) * 0.35, 1.4]) if T.FLINE
             else np.array([0.0, 1.4])) + 0.05 * rng.randn(2)
        lat = (np.array([rng.uniform(-T.WLINE, T.WLINE), 0.0]) if T.FLINE
               else np.zeros(2))
        sv = np.array([rng.uniform(0, smax) * rng.choice([-1, 1]), 0.0])
        held = 0; ok = False
        for step in range(0, 200, AS):
            f_app = T.field(p, g, lat) + (sv if np.linalg.norm(p - g) < T.RF else 0.0)
            o = torch.tensor(ob.obs(p, g, np.zeros(2), rng, None, f=f_app)[None], device=T.DEV)
            with torch.no_grad():
                chunk = net(o)[0].reshape(T.H, 2).cpu().numpy()
            for a in chunk[:AS]:
                f_app = T.field(p, g, lat) + (sv if np.linalg.norm(p - g) < T.RF else 0.0)
                p = p + np.clip(a, -T.DCLIP, T.DCLIP) + f_app
                held = held + 1 if np.linalg.norm(p - g) < T.TOL else 0
                if held >= T.TS_HOLD:
                    ok = True; break
            if ok:
                break
        succ += int(ok)
        parks.append(abs(p[0] - g[0]))
    return succ / n_ep, float(np.median(parks))


def cancel_gain(net, X, W):
    xs = torch.tensor(X[W][:256], device=T.DEV, requires_grad=True)
    a1x = net.chunk_from_obs(xs)[:, 0]
    g = torch.autograd.grad(a1x.sum(), xs)[0]
    return float(g[:, 12].mean())


data, ob = T.build_dataset(None, data_seed=0)
_evaltol = float(__import__("os").environ.get("EVALTOL", "0"))
if _evaltol > 0:
    T.TOL = _evaltol
    print(f"eval TOL relaxed to {_evaltol} (training data unchanged)")
import argparse, json
ap = argparse.ArgumentParser()
ap.add_argument("--seeds", type=int, default=2)
ap.add_argument("--seed0", type=int, default=0)
ap.add_argument("--out", default="")
args = ap.parse_args()
import os as _o
RES = {}
for arm in _o.environ.get("ARMS", "l2,pdropf").split(","):
    RES[arm] = []
    for s in range(args.seed0, args.seed0 + args.seeds):
        net = T.train((data, ob), arm, seed=s, steps=12000)
        sh = T.group_share(net, data[0], data[2])
        r = {}
        r["normal"] = rollout(net, ob)
        r["sensor=0"] = rollout(net, ob, sensor="zero")
        r["shift0.02"] = rollout(net, ob, shift=0.02)
        r["SRin"] = rollout(net, ob, inband=True)
        r["SRdose"], r["park"] = rollout_dose(net, ob)
        r["cgain"] = cancel_gain(net, data[0], data[2])
        print(f"{arm} s{s}: F-share {sh:.2f} | " +
              " ".join(f"{k} {v:.2f}" for k, v in r.items()), flush=True)
        RES[arm].append({"seed": s, "F_share": sh, **r})
    m = lambda k: sum(c[k] for c in RES[arm]) / len(RES[arm])
    print(f"== {arm}: F-share {m('F_share'):.2f} cgain {m('cgain'):+.2f} | normal {m('normal'):.2f} "
          f"SRin {m('SRin'):.2f} sensor0 {m('sensor=0'):.2f} shift02 {m('shift0.02'):.2f} "
          f"SRdose {m('SRdose'):.2f} park {m('park'):.3f}", flush=True)
if args.out:
    json.dump(RES, open(args.out, "w"), default=float)
