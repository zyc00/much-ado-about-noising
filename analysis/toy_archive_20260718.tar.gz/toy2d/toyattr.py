"""2D toy: input-feature attribution & representation collapse.

Config "attr" (main): reach + precision endgame with two obs groups —
V (dominant, high-dim, saturating: blind to the fine offset near the target)
and T (sparse-critical: carries exactly the fine residual, only near target).
Success requires holding within tol of g+delta; coarse-only policies miss by
|delta| > tol, so SR directly measures whether T got funded.

Config "fold" (secondary): approach(A, z-servo) -> hover(B, quiet at (0,0)) ->
lateral stroke(C, x-servo at B's height). Obs = (x, z, k noisy z-copies,
nuisance). Reproduces the scripted collapse/fold chain.

Losses: l2 | hg (per-sample sigma) | gdrop (L2 + V-group dropout) |
fact (factorized V/T encoders + learned gate) | oversamp (endgame x4).
Instruments: per-group Jacobian share (endgame vs reach), SR at AS in
{1,4,8}, basin interpolation (fold), per-phase gain ratio (fold).

Usage: python toyattr.py --config attr --losses l2,hg,gdrop,fact --seeds 10
"""
import argparse
import json

import numpy as np
import torch
import torch.nn as nn

DEV = "cuda" if torch.cuda.is_available() else "cpu"
import os as _os
WIDTH = int(_os.environ.get("WIDTH", "128"))
NEP = int(_os.environ.get("NEP", "300"))
CONFIG = _os.environ.get("TOYCFG", "attr")
H = 8
TOL = 0.03 if CONFIG == "force" else 0.02
DIMV = int(_os.environ.get("DIMVO", "0")) or (12 if CONFIG == "force" else 16)
TS_HOLD = 10
KSERVO = 0.25
VMAX = 0.15
RNEAR = 0.15
TREMOR = float(__import__("os").environ.get("TREMOR", "0.01"))
FA = float(_os.environ.get("FA", "0.06"))
FW = float(_os.environ.get("FW", "10"))
FC = float(_os.environ.get("FC", "0.5"))
RF = float(_os.environ.get("RF", "0.25"))
FNOISE = float(_os.environ.get("FNOISE", "0.015"))
SIGFLOOR = float(_os.environ.get("SIGFLOOR", "0.001"))
WLO = float(_os.environ.get("WLO", "0.02"))
WHI = float(_os.environ.get("WHI", "0.05"))
DCLIP = 0.3 if CONFIG == "force" else VMAX
FLINEMODE = _os.environ.get("FLINE", "0")
FLINE = FLINEMODE in ("1", "2")
CONTACT = float(_os.environ.get("CONTACT", "0.008"))
WLINE = float(_os.environ.get("WLINE", "0.08"))
LSOFT = float(_os.environ.get("LSOFT", "0.01"))


def field(p, g, wind):
    """Config "force": inside |p-g|<RF, a position-deterministic component
    FA*(sin(FW*dx)+FC)*x_hat (learnable from position on the tube) plus a
    per-episode constant wind (latent: resolvable ONLY via the force sensor).
    Zero outside the area."""
    if CONFIG != "force":
        return np.zeros(2)
    if FLINE:
        sgn = -1.0 if FLINEMODE == "2" else 1.0
        return np.array([sgn * FA * np.tanh((p[0] - wind[0]) / LSOFT), 0.0])
    if np.linalg.norm(p - g) >= RF:
        return np.zeros(2)
    return np.array([FA * (np.sin(FW * (p[0] - g[0])) + FC), 0.0]) + wind


# ---------------- data ----------------
def make_episode(rng, cfg):
    g = rng.uniform([-0.3, -0.3], [0.3, 0.3])
    delta = (np.zeros(2) if CONFIG == "force"
             else rng.uniform(0.03, 0.08) * _unit(rng))
    y0 = float(_os.environ.get("Y0", "1.4"))
    p = (np.array([rng.choice([-1, 1]) * 0.35, 1.4]) if FLINE
         else np.array([0.0, y0])) + 0.05 * rng.randn(2)
    tgt = g + delta
    wind = (np.array([rng.uniform(-WLINE, WLINE), 0.0]) if FLINE
            else rng.uniform(WLO, WHI) * _unit(rng))
    ps, acts = [], []
    held = 0
    incap = int(_os.environ.get("INCAP", "10000"))
    nin = 0
    for _ in range(int(_os.environ.get("EPLEN", "140"))):
        if CONFIG == "force" and np.linalg.norm(p - g) < RF:
            nin += 1
            if nin > incap:
                break
        f = field(p, g, wind)
        a = np.clip(KSERVO * (tgt - p), -VMAX, VMAX) - f
        a = a + TREMOR * rng.standard_t(3, 2)
        ps.append(p.copy()); acts.append(a.copy())
        zeta = float(_os.environ.get("EXNOISE", "0.0")) * rng.randn(2)
        p = p + np.clip(a + zeta, -DCLIP, DCLIP) + f
        if FLINEMODE == "2" and abs(p[0] - wind[0]) < CONTACT:
            return None
        if np.linalg.norm(p - tgt) < TOL:
            held += 1
            if held >= TS_HOLD + 4:
                break
        else:
            held = 0
    if CONFIG == "force":
        return np.array(ps), np.array(acts), g, delta, wind
    return np.array(ps), np.array(acts), g, delta


def _unit(rng):
    v = rng.randn(2)
    return v / (np.linalg.norm(v) + 1e-9)


class AttrObs:
    """V: 16-dim [proj(p), proj(g), saturating proj of (p-g)] + noise (blind to
    fine residual near target). T: 2-dim fine residual (g+delta-p), gated to
    near range, ~0 elsewhere."""

    def __init__(self, seed=0):
        r = np.random.RandomState(seed)
        self.Wp = r.randn(6, 2) / np.sqrt(2)
        self.Wg = r.randn(6, 2) / np.sqrt(2)
        self.Ws = r.randn(4, 2) / np.sqrt(2)
        self.dim_v, self.dim_t = 16, 2

    def obs(self, p, g, delta, rng, ood=None):
        sat = np.tanh(25.0 * (self.Ws @ (p - g)))
        v = np.concatenate([self.Wp @ p, self.Wg @ g, sat]) + 0.02 * rng.randn(16)
        near = np.linalg.norm(p - g) < RNEAR
        t = (g + delta - p) if near else np.zeros(2)
        t = t + float(__import__("os").environ.get("TNOISE", "0.002")) * rng.randn(2)
        return np.concatenate([v, t]).astype(np.float32)


class RedunObs:
    """Config "redun": V additionally carries a CLEAN fine channel
    tanh(4*Wf(g+delta-p)) (noise 0.005), so T (noise 0.01) is strictly
    redundant on the training support. OOD families corrupt only V-fine:
    bias (V-fine reports r+b), gain (k*r), occl (V-fine zeroed)."""

    def __init__(self, seed=0):
        r = np.random.RandomState(seed)
        self.Wp = r.randn(6, 2) / np.sqrt(2)
        self.Wg = r.randn(6, 2) / np.sqrt(2)
        self.Wf = r.randn(4, 2) / np.sqrt(2)
        self.dim_v, self.dim_t = 16, 2

    def obs(self, p, g, delta, rng, ood=None):
        r_ = g + delta - p
        rv = r_
        if ood is not None and ood["kind"] == "bias":
            rv = r_ + ood["vec"]
        elif ood is not None and ood["kind"] == "gain":
            rv = ood["k"] * r_
        fine = np.tanh(4.0 * (self.Wf @ rv))
        v = np.concatenate([self.Wp @ p, self.Wg @ g, fine]) + 0.005 * rng.randn(16)
        if ood is not None and ood["kind"] == "occl":
            v[12:16] = 0.0
        near = np.linalg.norm(p - g) < RNEAR
        t = r_ if near else np.zeros(2)
        t = t + 0.01 * rng.randn(2)
        return np.concatenate([v, t]).astype(np.float32)


class ForceObs:
    """Config "force": position projections (12, noise 0.005) + force sensor
    (2, noise FNOISE). On the demo tube f = field(p,g) deterministically, so
    the force input is exactly redundant given position ON-SUPPORT."""

    def __init__(self, seed=0):
        r = np.random.RandomState(seed)
        self.Wp = r.randn(6, 2) / np.sqrt(2)
        self.Wg = r.randn(6, 2) / np.sqrt(2)
        self.dim_v, self.dim_t = 12, 2

    def obs(self, p, g, delta, rng, ood=None, f=None):
        v = np.concatenate([self.Wp @ p, self.Wg @ g]) + 0.005 * rng.randn(12)
        fs = (f if f is not None else np.zeros(2)) + FNOISE * rng.randn(2)
        return np.concatenate([v, fs]).astype(np.float32)


def build_dataset(cfg, data_seed=0, n_ep=NEP):
    rng = np.random.RandomState(data_seed)
    ob = (ForceObs(seed=123) if CONFIG == "force"
          else RedunObs(seed=123) if CONFIG == "redun" else AttrObs(seed=123))
    X, Y, W = [], [], []
    keep = float(_os.environ.get("INSTRIP_KEEP", "1.0"))
    made = 0
    while made < n_ep:
        if CONFIG == "force":
            out = make_episode(rng, cfg)
            if out is None:
                continue
            ps, acts, g, delta, wind = out
            if FLINE and abs(g[0]) < WLINE and rng.rand() > keep:
                continue
            made += 1
            inkeep = float(_os.environ.get("INKEEP", "1.0"))
            obs = np.array([ob.obs(p, g, delta, rng, f=field(p, g_, wind))
                            for p, g_ in zip(ps, [g] * len(ps))])
            if FLINE:
                endg_line = np.array([abs(p[0] - wind[0]) < 0.06 for p in ps])
        else:
            ps, acts, g, delta = make_episode(rng, cfg)
            made += 1
            obs = np.array([ob.obs(p, g, delta, rng) for p in ps])
        endg = (endg_line if (CONFIG == "force" and FLINE)
                else np.array([np.linalg.norm(p - g) < RNEAR for p in ps]))
        for t in range(len(ps) - H):
            if (CONFIG == "force" and not FLINE
                    and np.linalg.norm(ps[t] - g) < RF and rng.rand() > float(_os.environ.get("INKEEP", "1.0"))):
                continue
            X.append(obs[t]); Y.append(acts[t:t + H].reshape(-1)); W.append(endg[t])
    return (np.array(X, dtype=np.float32), np.array(Y, dtype=np.float32),
            np.array(W)), ob


# ---------------- model ----------------
class Net(nn.Module):
    def __init__(self, din, fact=False, dim_v=16, dim_t=2, addf=False):
        super().__init__()
        self.fact = fact
        self.addf = addf
        self.dim_v, self.dim_t = dim_v, dim_t
        if addf:
            self.ev = nn.Sequential(nn.Linear(dim_v, 64), nn.ReLU(), nn.Linear(64, 64), nn.ReLU())
            self.et = nn.Sequential(nn.Linear(dim_t, 64), nn.ReLU(), nn.Linear(64, 64), nn.ReLU())
            self.head = nn.Linear(64, 2 * H + 1)
        elif fact:
            self.ev = nn.Sequential(nn.Linear(dim_v, 96), nn.ReLU(), nn.Linear(96, 64), nn.ReLU())
            self.et = nn.Sequential(nn.Linear(dim_t, 96), nn.ReLU(), nn.Linear(96, 64), nn.ReLU())
            self.gate = nn.Sequential(nn.Linear(din, 32), nn.ReLU(), nn.Linear(32, 2))
            self.head = nn.Linear(64, 2 * H + 1)
        else:
            self.f = nn.Sequential(nn.Linear(din, WIDTH), nn.ReLU(), nn.Linear(WIDTH, WIDTH), nn.ReLU())
            self.head = nn.Linear(WIDTH, 2 * H + 1)

    def set_norm(self, xlo, xhi, ylo, yhi):
        dev = next(self.parameters()).device
        self.xc = torch.tensor((xlo + xhi) / 2, device=dev)
        self.xs = torch.tensor((xhi - xlo) / 2 + 1e-8, device=dev)
        self.yc = torch.tensor((ylo + yhi) / 2, device=dev)
        self.ys = torch.tensor((yhi - ylo) / 2 + 1e-8, device=dev)

    def features(self, x):
        if getattr(self, "xc", None) is not None:
            x = (x - self.xc) / self.xs
        if getattr(self, "maskv", False):
            x = torch.cat([x[:, :12], torch.zeros_like(x[:, 12:16]), x[:, 16:]], dim=1)
        fsc = getattr(self, "fscale", 1.0)
        if fsc != 1.0:
            x = torch.cat([x[:, :self.dim_v], x[:, self.dim_v:] * fsc], dim=1)
        if self.addf:
            return self.ev(x[:, :self.dim_v]) + self.et(x[:, self.dim_v:])
        if self.fact:
            zv = self.ev(x[:, :self.dim_v]); zt = self.et(x[:, self.dim_v:])
            w = torch.softmax(self.gate(x), dim=1)
            return w[:, :1] * zv + w[:, 1:] * zt
        return self.f(x)

    def _fwd_norm(self, x):
        out = self.head(self.features(x))
        return out[:, :2 * H], out[:, -1]

    def _denorm(self, pn):
        if getattr(self, "yc", None) is not None:
            return pn * self.ys + self.yc
        return pn

    def chunk_from_obs(self, x):
        return self._denorm(self.head(self.features(x))[:, :2 * H])

    def forward(self, x):
        out = self.head(self.features(x))
        return self._denorm(out[:, :2 * H]), out[:, -1]


class MipNet(nn.Module):
    """Conditional flow matching with a 2-step Euler sampler (minimal MIP
    analog: generative anchor + few-step flow map). Actions z-scored."""

    def __init__(self, dobs):
        super().__init__()
        self.fact = False
        self.dobs = dobs
        self.f = nn.Sequential(nn.Linear(dobs + 2 * H + 1, WIDTH), nn.ReLU(),
                               nn.Linear(WIDTH, WIDTH), nn.ReLU())
        self.head = nn.Linear(WIDTH, 2 * H)
        self.register_buffer("ymu", torch.zeros(2 * H))
        self.register_buffer("ysd", torch.ones(2 * H))

    def set_norm(self, xlo, xhi, ylo, yhi):
        dev = next(self.parameters()).device
        self.xc = torch.tensor((xlo + xhi) / 2, device=dev)
        self.xs = torch.tensor((xhi - xlo) / 2 + 1e-8, device=dev)

    def _nobs(self, obs):
        if getattr(self, "xc", None) is not None:
            return (obs - self.xc) / self.xs
        return obs

    def vel(self, obs, yt, t):
        return self.head(self.f(torch.cat([self._nobs(obs), yt, t], dim=1)))

    def _sample(self, obs, eps):
        n = getattr(self, "nsteps", 2)
        x = eps
        for k in range(n):
            t = torch.full((len(obs), 1), k / n, device=obs.device)
            x = x + (1.0 / n) * self.vel(obs, x, t)
        return x * self.ysd + self.ymu

    def chunk_from_obs(self, obs):
        if getattr(self, "x0mode", False):
            z = torch.zeros(len(obs), 2 * H, device=obs.device)
            t0 = torch.zeros(len(obs), 1, device=obs.device)
            return self.vel(obs, z, t0) * self.ysd + self.ymu
        return self._sample(obs, torch.zeros(len(obs), 2 * H, device=obs.device))

    def features(self, obs):
        z = torch.zeros(len(obs), 2 * H + 1, device=obs.device)
        return self.f(torch.cat([self._nobs(obs), z], dim=1))

    def forward(self, obs):
        sc = float(_os.environ.get("MIPEPS", "0"))
        eps = sc * torch.randn(len(obs), 2 * H, device=obs.device)
        return self._sample(obs, eps), torch.zeros(len(obs), device=obs.device)


def _ns5(G, steps=5):
    a, b, c = (3.4445, -4.7750, 2.0315)
    X = G / (G.norm() + 1e-7)
    tp = G.size(0) > G.size(1)
    if tp:
        X = X.T
    for _ in range(steps):
        A = X @ X.T
        B = b * A + c * A @ A
        X = a * X + B @ X
    return (X.T if tp else X)


class _Muon(torch.optim.Optimizer):
    def __init__(self, params, lr=0.02, momentum=0.95):
        super().__init__(params, dict(lr=lr, momentum=momentum))

    @torch.no_grad()
    def step(self):
        for gr in self.param_groups:
            for p in gr["params"]:
                if p.grad is None:
                    continue
                st = self.state[p]
                if "m" not in st:
                    st["m"] = torch.zeros_like(p.grad)
                st["m"].mul_(gr["momentum"]).add_(p.grad)
                g = p.grad.add(st["m"], alpha=gr["momentum"])
                g = _ns5(g)
                p.add_(g, alpha=-gr["lr"] * max(1, p.size(0) / p.size(1)) ** 0.5)


def train(data, loss_name, seed, steps=int(_os.environ.get("STEPS", "4000"))):
    (X, Y, Wend), _ = data
    torch.manual_seed(seed)
    net = (MipNet(X.shape[1]) if loss_name in ("mip", "flow8", "x0d")
           else Net(X.shape[1], fact=(loss_name == "fact"), dim_v=DIMV,
                    addf=(loss_name in ("addf", "adp")))).to(DEV)
    if loss_name == "flow8":
        net.nsteps = 8
    if loss_name == "x0d":
        net.x0mode = True
    if loss_name == "tonly":
        net.maskv = True
    if loss_name == "fscale":
        net.fscale = 5.0
    aux = None
    if loss_name == "hgw":
        aux = nn.Sequential(nn.Linear(X.shape[1], 32), nn.ReLU(), nn.Linear(32, 1)).to(DEV)
    params = list(net.parameters()) + (list(aux.parameters()) if aux else [])
    if _os.environ.get("OPT", "adam") == "muon":
        p2 = [p for p in params if p.ndim == 2]
        p1 = [p for p in params if p.ndim != 2]
        muon = _Muon(p2, lr=float(_os.environ.get("MUONLR", "0.02")))
        adam1 = torch.optim.Adam(p1, lr=1e-3)

        class _Both:
            def zero_grad(self):
                muon.zero_grad(); adam1.zero_grad()

            def step(self):
                muon.step(); adam1.step()
        opt = _Both()
    elif _os.environ.get("OPT", "adam") == "sgd":
        opt = torch.optim.SGD(params, lr=float(_os.environ.get("LR", "0.05")), momentum=0.9)
    else:
        opt = torch.optim.Adam(params, lr=float(_os.environ.get("LR", "1e-3")),
                               weight_decay=float(_os.environ.get("WD", "0")))
    Xt = torch.tensor(X, device=DEV); Yt = torch.tensor(Y, device=DEV)
    if _os.environ.get("NORMIO", "1") == "1":
        net.set_norm(X.min(0), X.max(0), Y.min(0), Y.max(0))
    Wt = torch.tensor(Wend.astype(np.float32), device=DEV)
    n = len(Xt)
    if loss_name in ("mip", "flow8", "x0d"):
        net.ymu.copy_(Yt.mean(0)); net.ysd.copy_(Yt.std(0) + 1e-6)
    rng = np.random.RandomState(seed)
    endg_idx = np.where(Wend)[0]
    import math as _math
    _sched = _os.environ.get("SCHED", "none")
    _lr0 = float(_os.environ.get("LR", "1e-3"))
    for it in range(steps):
        if _sched == "cos" and hasattr(opt, "param_groups"):
            for _g in opt.param_groups:
                _g["lr"] = _lr0 * 0.5 * (1 + _math.cos(_math.pi * it / steps))
        if loss_name == "oversamp":
            k = 256
            idx = np.concatenate([rng.randint(0, n, k // 2), endg_idx[rng.randint(0, len(endg_idx), k // 2)]])
        else:
            idx = rng.randint(0, n, int(_os.environ.get("BATCH", "256")))
        xb, yb = Xt[idx], Yt[idx]
        if loss_name == "gdrop":
            mask = (torch.rand(len(xb), 1, device=DEV) > 0.3).float()
            xb = torch.cat([xb[:, :DIMV] * mask, xb[:, DIMV:]], dim=1)
        if loss_name in ("pdropf", "adp"):
            pd = float(_os.environ.get("PDROP", "0.5"))
            infield = Wt[idx].unsqueeze(1)
            mask = 1.0 - infield * (torch.rand(len(xb), 1, device=DEV) < pd).float()
            xb = torch.cat([xb[:, :DIMV] * mask, xb[:, DIMV:]], dim=1)
        if loss_name in ("mip", "flow8", "x0d"):
            yn = (yb - net.ymu) / net.ysd
            eps = torch.randn_like(yn)
            tt = torch.rand(len(yn), 1, device=DEV)
            ytt = (1 - tt) * eps + tt * yn
            v = net.vel(xb, ytt, tt)
            tgt = yn if loss_name == "x0d" else (yn - eps)
            loss = ((v - tgt) ** 2).sum(dim=1).mean()
            opt.zero_grad(); loss.backward(); opt.step()
            continue
        pred, sraw = net._fwd_norm(xb)
        ybn = (yb - net.yc) / net.ys if getattr(net, "yc", None) is not None else yb
        r2 = ((pred - ybn) ** 2).sum(dim=1)
        if loss_name == "l2tn":
            ybn = (yb - net.yc) / net.ys
            ybn = ybn + float(_os.environ.get("TN", "1.0")) * torch.randn_like(ybn)
            loss = ((pred - ybn) ** 2).sum(dim=1).mean()
        elif loss_name == "hgw":
            sig = torch.nn.functional.softplus(aux(xb)).squeeze(1) + SIGFLOOR
            loss = (0.5 * r2.detach() / sig ** 2 + (2 * H) * torch.log(sig)).mean() \
                 + (0.5 * r2 / sig.detach() ** 2).mean()
        elif loss_name == "hg":
            sig = torch.nn.functional.softplus(sraw) + SIGFLOOR
            loss = (0.5 * r2 / sig ** 2 + (2 * H) * torch.log(sig)).mean()
        elif loss_name == "hgu":
            w = (r2.detach() / (r2.detach().mean() + 1e-12)).clamp(max=5.0)
            loss = (w * r2).mean()
        elif loss_name in ("ht", "ht1"):
            sig = torch.nn.functional.softplus(sraw) + SIGFLOOR
            nu = 1.0 if loss_name == "ht1" else 3.0
            z2 = r2 / (sig ** 2 * (2 * H))
            loss = (0.5 * (nu + 2 * H) * torch.log1p(z2 * (2 * H) / nu) + (2 * H) * torch.log(sig)).mean()
        else:
            loss = r2.mean()
        opt.zero_grad(); loss.backward(); opt.step()
    return net


# ---------------- instruments ----------------
def collapse_stats(net, X, sel):
    """Representation collapse at selected states: PR of penultimate-feature
    covariance eigenvalues, and PR / kappa10 of stacked input-Jacobian
    singular values (same statistics as scripts/probe_commit.py)."""
    xs = torch.tensor(X[sel][:256], device=DEV, requires_grad=True)
    z = net.features(xs)
    zc = z - z.mean(dim=0, keepdim=True)
    ev = torch.linalg.eigvalsh(zc.T @ zc / len(zc)).clamp(min=0)
    pr_feat = float(ev.sum() ** 2 / ((ev ** 2).sum() + 1e-12))
    pred = net.chunk_from_obs(xs)
    rows = []
    for k in range(0, 2 * H, 2):
        g = torch.autograd.grad(pred[:, k].sum(), xs, retain_graph=True)[0]
        rows.append(g)
    J = torch.stack(rows, dim=1).reshape(-1, xs.shape[1])
    s = torch.linalg.svdvals(J)
    s2 = s ** 2
    pr_jac = float(s2.sum() ** 2 / ((s2 ** 2).sum() + 1e-12))
    k10 = float(s[0] / (s[min(9, len(s) - 1)] + 1e-12))
    return pr_feat, pr_jac, k10


def group_share(net, X, sel):
    """Jacobian Frobenius share of the T group at selected states."""
    xs = torch.tensor(X[sel][:64], device=DEV, requires_grad=True)
    pred = net.chunk_from_obs(xs)
    gT = gV = 0.0
    for k in range(0, 2 * H, 4):
        g = torch.autograd.grad(pred[:, k].sum(), xs, retain_graph=True)[0]
        gV += float((g[:, :DIMV] ** 2).sum()); gT += float((g[:, DIMV:] ** 2).sum())
    return gT / (gT + gV + 1e-12)


def rollout_sr(net, ob, n_ep=100, AS=8, seed=999, ood_kind=None, dose=0.0):
    rng = np.random.RandomState(seed)
    succ = 0
    for _ in range(n_ep):
        g = rng.uniform([-0.3, -0.3], [0.3, 0.3])
        delta = (np.zeros(2) if CONFIG == "force"
                 else rng.uniform(0.03, 0.08) * _unit(rng))
        p = np.array([0.0, 1.4]) + 0.05 * rng.randn(2)
        tgt = g + delta
        if CONFIG == "force" and FLINE:
            wind = np.array([rng.uniform(-WLINE, WLINE), 0.0])
            if _os.environ.get("GINBAND", "0") == "1":
                g[0] = rng.uniform(-WLINE - 0.02, WLINE + 0.02)
            tgt = g + delta
        elif CONFIG == "force":
            wind = rng.uniform(WLO, WHI) * _unit(rng)
        else:
            wind = np.zeros(2)
        ood = None
        if ood_kind == "bias":
            ood = {"kind": "bias", "vec": dose * _unit(rng)}
        elif ood_kind == "gain":
            ood = {"kind": "gain", "k": dose}
        elif ood_kind == "occl":
            ood = {"kind": "occl"}
        held = 0; ok = False
        for step in range(0, 200, AS):
            if CONFIG == "force":
                o = torch.tensor(ob.obs(p, g, delta, rng, ood, f=field(p, g, wind))[None], device=DEV)
            else:
                o = torch.tensor(ob.obs(p, g, delta, rng, ood)[None], device=DEV)
            with torch.no_grad():
                chunk = net(o)[0].reshape(H, 2).cpu().numpy()
            for a in chunk[:AS]:
                p = p + np.clip(a, -DCLIP, DCLIP) + field(p, g, wind)
                if np.linalg.norm(p - tgt) < TOL:
                    held += 1
                    if held >= TS_HOLD:
                        ok = True; break
                else:
                    held = 0
            if ok:
                break
        succ += int(ok)
    return succ / n_ep


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--losses", default="l2,hg,gdrop,fact,oversamp")
    ap.add_argument("--seeds", type=int, default=10)
    ap.add_argument("--out", default="analysis/toy2d/attr_results.json")
    args = ap.parse_args()
    data, ob = build_dataset(None, data_seed=0)
    X, Y, Wend = data[0], data[1], data[2]
    data = ((X, Y, Wend), ob)
    res = {}
    for loss in args.losses.split(","):
        cells = []
        for s in range(args.seeds):
            net = train(((X, Y, Wend), ob), loss, seed=s)
            sh_end = group_share(net, X, Wend)
            sh_reach = group_share(net, X, ~Wend)
            prf_e, prj_e, k10_e = collapse_stats(net, X, Wend)
            prf_r, prj_r, k10_r = collapse_stats(net, X, ~Wend)
            srs = {a: rollout_sr(net, ob, AS=a, seed=999) for a in (1, 2, 4, 8)}
            oods = {}
            if CONFIG == "redun":
                for kind, dose in [("bias", 0.02), ("bias", 0.04), ("bias", 0.08),
                                   ("occl", 0.0), ("gain", 1.5), ("gain", 2.0)]:
                    oods[f"{kind}{dose:g}"] = rollout_sr(net, ob, AS=8, seed=999,
                                                         ood_kind=kind, dose=dose)
            cells.append({"seed": s, "T_share_endgame": sh_end, "T_share_reach": sh_reach,
                          "PRfeat_end": prf_e, "PRjac_end": prj_e, "k10_end": k10_e,
                          "PRfeat_reach": prf_r, "PRjac_reach": prj_r, "k10_reach": k10_r,
                          "SR": srs, "OOD": oods})
            oo = (" | OOD " + " ".join(f"{k} {v:.2f}" for k, v in oods.items())) if oods else ""
            print(f"{loss} s{s}: T-share end/reach = {sh_end:.3f}/{sh_reach:.3f} | "
                  f"PRfeat {prf_e:.1f}/{prf_r:.1f} PRjac {prj_e:.1f}/{prj_r:.1f} k10 {k10_e:.1f}/{k10_r:.1f} | "
                  f"SR AS1/2/4/8 = {srs[1]:.2f}/{srs[2]:.2f}/{srs[4]:.2f}/{srs[8]:.2f}{oo}", flush=True)
        res[loss] = cells
        m = lambda k: np.mean([c[k] for c in cells])
        ms = lambda a: np.mean([c["SR"][a] for c in cells])
        sd = lambda a: np.std([c["SR"][a] for c in cells])
        print(f"== {loss}: T-share endgame {m('T_share_endgame'):.3f} | "
              f"PRfeat end/reach {m('PRfeat_end'):.1f}/{m('PRfeat_reach'):.1f} k10 {m('k10_end'):.1f} | "
              f"SR8 {ms(8):.2f}±{sd(8):.2f} SR1 {ms(1):.2f}±{sd(1):.2f}", flush=True)
        if CONFIG == "redun" and cells and cells[0]["OOD"]:
            oo = " ".join(f"{k} {np.mean([c['OOD'][k] for c in cells]):.2f}±{np.std([c['OOD'][k] for c in cells]):.2f}"
                          for k in cells[0]["OOD"])
            print(f"== {loss} OOD: {oo}", flush=True)
    json.dump(res, open(args.out, "w"), default=float)
    print("TOYATTR-DONE")


if __name__ == "__main__":
    main()
