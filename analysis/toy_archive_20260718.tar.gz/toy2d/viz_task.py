"""Visualize the 2D attribution toy: geometry, observation groups, label
economics, and trained-policy endgame behavior (L2 vs hetero-t)."""
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

import toyattr as T

OUT = os.path.join(os.path.dirname(__file__), "task_viz.png")


def demo_traj(seed):
    rng = np.random.RandomState(seed)
    return T.make_episode(rng, None)


def rollout_traj(net, ob, g, delta, seed, AS=8, nsteps=200):
    rng = np.random.RandomState(seed)
    p = np.array([0.0, 1.4]) + 0.05 * rng.randn(2)
    tgt = g + delta
    traj = [p.copy()]
    held = 0
    for step in range(0, nsteps, AS):
        o = torch.tensor(ob.obs(p, g, delta, rng)[None], device=T.DEV)
        with torch.no_grad():
            chunk = net(o)[0].reshape(T.H, 2).cpu().numpy()
        for a in chunk[:AS]:
            p = p + np.clip(a, -T.VMAX, T.VMAX)
            traj.append(p.copy())
            held = held + 1 if np.linalg.norm(p - tgt) < T.TOL else 0
            if held >= T.TS_HOLD:
                return np.array(traj), True
    return np.array(traj), False


fig, axes = plt.subplots(2, 2, figsize=(12.5, 11))

# --- A: task geometry + demonstrations -------------------------------------
ax = axes[0, 0]
for s in range(8):
    ps, acts, g, delta = demo_traj(s)
    (ln,) = ax.plot(ps[:, 0], ps[:, 1], lw=1.0, alpha=0.8)
    c = ln.get_color()
    ax.plot(*g, "o", color=c, ms=5, mfc="none")
    ax.plot(*(g + delta), "x", color=c, ms=6)
ax.add_patch(plt.Rectangle((-0.3, -0.3), 0.6, 0.6, fill=False, ls=":", color="gray"))
ax.plot([], [], "ko", mfc="none", label="goal g (V observes)")
ax.plot([], [], "kx", label="true target g+$\\delta$ (only T observes)")
ax.scatter([0.0], [1.4], marker="s", c="k", s=30, label="start region")
ax.set_title("A. Task: reach + precision endgame\n(8 demonstrations, tremor 0.04·t(3))")
ax.legend(loc="lower right", fontsize=8)
ax.set_aspect("equal")

# --- B: endgame zoom --------------------------------------------------------
ax = axes[0, 1]
ps, acts, g, delta = demo_traj(3)
ax.plot(ps[:, 0], ps[:, 1], "-", lw=1.0, color="tab:blue", alpha=0.9, label="demo path")
ax.plot(ps[:, 0], ps[:, 1], ".", ms=3, color="tab:blue")
ax.add_patch(plt.Circle(g, T.RNEAR, fill=False, ls="--", color="tab:orange", lw=1.5))
ax.add_patch(plt.Circle(g + delta, T.TOL, fill=False, color="tab:green", lw=1.5))
ax.plot(*g, "o", color="k", mfc="none", ms=7, label="g")
ax.plot(*(g + delta), "x", color="k", ms=8, label="g+$\\delta$")
ax.annotate("T gate ON\n($|p-g|<0.15$)", xy=(g[0] + T.RNEAR * 0.72, g[1] + T.RNEAR * 0.72),
            fontsize=8, color="tab:orange")
ax.annotate("success: hold 10 steps\nwithin tol 0.02", xy=(g + delta), xytext=(g[0] + 0.06, g[1] - 0.10),
            fontsize=8, color="tab:green", arrowprops=dict(arrowstyle="-", color="tab:green", lw=0.7))
m = 0.22
ax.set_xlim(g[0] - m, g[0] + m); ax.set_ylim(g[1] - m, g[1] + m)
ax.set_title("B. Endgame zoom: $|\\delta|\\in[0.03,0.08]$ > tol 0.02,\nso a V-only (coarse) policy misses")
ax.legend(loc="upper left", fontsize=8)
ax.set_aspect("equal")

# --- C: observation channels along one episode -----------------------------
ax = axes[1, 0]
ob = T.AttrObs(seed=123)
rng = np.random.RandomState(11)
ps, acts, g, delta = demo_traj(11)
obs = np.array([ob.obs(p, g, delta, rng) for p in ps])
dist = np.linalg.norm(ps - g, axis=1)
tt = np.arange(len(ps))
ax.plot(tt, dist, "k-", lw=1.5, label="$|p-g|$")
ax.plot(tt, np.abs(obs[:, 12]), color="tab:red", lw=1.0,
        label="V saturating ch. $|\\tanh(25\\,W_s(p-g))|$")
ax.plot(tt, np.linalg.norm(obs[:, 16:], axis=1), color="tab:orange", lw=1.2,
        label="$\\|T\\|$ (gated fine residual)")
ax.plot(tt, np.linalg.norm(acts, axis=1), color="tab:blue", lw=0.8, alpha=0.7,
        label="$\\|a\\|$ (label)")
on = np.argmax(dist < T.RNEAR)
ax.axvline(on, color="tab:orange", ls=":", lw=1)
ax.text(on + 1, 1.05, "gate opens", fontsize=8, color="tab:orange")
ax.set_yscale("log"); ax.set_ylim(1e-3, 2.0)
ax.set_xlabel("episode step")
ax.set_title("C. Observation economics: V saturates (flat = uninformative)\nprecisely where T becomes the only useful input")
ax.legend(fontsize=8, loc="lower left")

# --- D: trained-policy endgame rollouts ------------------------------------
ax = axes[1, 1]
data, ob2 = T.build_dataset(None, data_seed=0)
nets = {}
for name in ("l2", "ht"):
    nets[name] = T.train((data, ob2), name, seed=0, steps=4000)
rngG = np.random.RandomState(77)
g = rngG.uniform([-0.3, -0.3], [0.3, 0.3])
delta = rngG.uniform(0.03, 0.08) * T._unit(rngG)
cols = {"l2": "tab:red", "ht": "tab:green"}
labels = {"l2": "L2 policy", "ht": "hetero-t policy"}
for name in ("l2", "ht"):
    nsucc = 0
    for s in range(8):
        traj, ok = rollout_traj(nets[name], ob, g, delta, seed=200 + s)
        nsucc += ok
        ax.plot(traj[:, 0], traj[:, 1], color=cols[name], lw=0.9,
                alpha=0.65, label=labels[name] if s == 0 else None)
    labels[name] += f"  ({nsucc}/8 hold)"
h, _ = ax.get_legend_handles_labels()
ax.legend(h, [labels["l2"], labels["ht"]], loc="upper left", fontsize=8)
ax.add_patch(plt.Circle(g + delta, T.TOL, fill=False, color="k", lw=1.2))
ax.add_patch(plt.Circle(g, T.RNEAR, fill=False, ls="--", color="gray", lw=0.8))
ax.plot(*g, "o", color="k", mfc="none", ms=7)
ax.plot(*(g + delta), "kx", ms=8)
m = 0.2
ax.set_xlim(g[0] - m, g[0] + m); ax.set_ylim(g[1] - m, g[1] + m)
ax.set_title("D. Trained policies (seed 0, 4k steps), endgame rollouts, AS=8:\nwhere each policy settles relative to the $\\delta$-offset target")
ax.set_aspect("equal")

for a in axes.flat:
    a.grid(alpha=0.25, lw=0.4)
fig.suptitle("2D attribution toy (width 32, tremor 0.04, T-noise 0.005, 150 episodes)", y=0.995)
fig.tight_layout()
fig.savefig(OUT, dpi=150)
print("saved", OUT)
