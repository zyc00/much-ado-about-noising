"""Slide-ready two-panel money figure: L2 fails under drift, feature-keeping
losses don't. Uses the FNOISE=0.005 showcase point."""
import glob
import json
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

import toyattr as T

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "money_fig.png")

ARMS = ["l2", "ht", "hg", "mip", "flow8"]
NAME = {"l2": "L2 (MSE)", "ht": "hetero-t", "hg": "hetero-G", "mip": "MIP", "flow8": "Flow"}
COL = {"l2": "#d62728", "ht": "#9467bd", "hg": "#ff9896", "mip": "#1f77b4", "flow8": "#17becf"}


def load_cells(arm):
    cells = []
    for f in ("sweep_fn0.005.json", "force_fn005_extra.json", "force_fn005_s3to5.json"):
        p = os.path.join(HERE, f)
        if os.path.exists(p):
            cells += json.load(open(p)).get(arm, [])
    seen, out = set(), []
    for c in cells:
        if c["seed"] not in seen:
            seen.add(c["seed"]); out.append(c)
    return out


R = {a: load_cells(a) for a in ARMS}
fig = plt.figure(figsize=(15, 5.4))
gs = fig.add_gridspec(1, 4, width_ratios=[2.1, 1, 1, 1], wspace=0.28)
ax = fig.add_subplot(gs[0])

x = np.arange(len(ARMS))
id_sr = [np.mean([c["normal"] for c in R[a]]) for a in ARMS]
dr_sr = [np.mean([c["shift0.02"] for c in R[a]]) for a in ARMS]
dr_sd = [np.std([c["shift0.02"] for c in R[a]]) for a in ARMS]
w = 0.38
ax.bar(x - w / 2, id_sr, w, color="0.6", label="training conditions")
ax.bar(x + w / 2, dr_sr, w, color=[COL[a] for a in ARMS], yerr=dr_sd,
       error_kw=dict(lw=1, capsize=3), label="deployment (field drifted)")
for i in range(len(ARMS)):
    ax.text(x[i] + w / 2, dr_sr[i] + 0.035, f"{dr_sr[i]:.2f}", ha="center",
            fontsize=12, fontweight="bold")
ax.set_xticks(x); ax.set_xticklabels([NAME[a] for a in ARMS], fontsize=10.5)
ax.set_ylabel("success rate", fontsize=12)
ax.set_ylim(0, 1.18)
ax.legend(fontsize=10, loc="lower right")
ax.set_title("All identical in training; only L2 collapses at deployment\n"
             "(it dropped the force feature: F-share 0.43 vs 0.57-0.86)", fontsize=11.5)
ax.grid(alpha=0.25, lw=0.4, axis="y")

data, ob = T.build_dataset(None, data_seed=0)
gg = np.array([0.1, -0.05]); sv = np.array([0.02, 0.0])
l2_seed = min(R["l2"], key=lambda c: c["shift0.02"])["seed"]


def roll(net, seed, drifted):
    rng = np.random.RandomState(seed)
    p = np.array([0.079, 0.25]) + 0.02 * rng.randn(2)
    traj = [p.copy()]
    dv = sv if drifted else np.zeros(2)
    for step in range(160):
        f_app = T.field(p, gg, np.zeros(2)) + (dv if np.linalg.norm(p - gg) < T.RF else 0.0)
        o = torch.tensor(ob.obs(p, gg, np.zeros(2), rng, None, f=f_app)[None], device=T.DEV)
        with torch.no_grad():
            act = net(o)[0].reshape(T.H, 2).cpu().numpy()[0]
        p = p + np.clip(act, -T.DCLIP, T.DCLIP) + f_app
        traj.append(p.copy())
    return np.array(traj)


VERDICT = {"l2": "leaves its baseline\n-> misses", "ht": "stays on baseline\n-> holds",
           "flow8": "stays on baseline\n-> holds"}
for k, a in enumerate(("l2", "ht", "flow8")):
    axm = fig.add_subplot(gs[k + 1])
    net = T.train((data, ob), a, seed=l2_seed if a == "l2" else 0, steps=12000)
    for s_ in range(3):
        tb = roll(net, 500 + s_, False)
        td = roll(net, 500 + s_, True)
        axm.plot(tb[:, 0], tb[:, 1], color="0.45", lw=1.3, ls="--", alpha=0.8,
                 label="no drift" if s_ == 0 else None)
        axm.plot(td[:, 0], td[:, 1], color=COL[a], lw=1.7, alpha=0.9,
                 label="drifted field" if s_ == 0 else None)
    axm.add_patch(plt.Circle(gg, T.RF, fill=False, ls="--", color="tab:red", lw=1.2))
    axm.add_patch(plt.Circle(gg, 0.045, fill=False, color="k", lw=1.6))
    axm.plot(*gg, "kx", ms=9, mew=2)
    axm.set_xlim(gg[0] - 0.22, gg[0] + 0.22); axm.set_ylim(gg[1] - 0.2, gg[1] + 0.33)
    axm.set_aspect("equal")
    axm.set_xticks([]); axm.set_yticks([])
    axm.set_title(f"{NAME[a]}: {VERDICT[a]}", fontsize=11, color=COL[a])
    if k == 0:
        axm.legend(fontsize=8.5, loc="lower left")
        axm.annotate("start: entering\nthe force area", (0.079, 0.25), xytext=(gg[0] - 0.21, gg[1] + 0.19),
                     fontsize=8.5, arrowprops=dict(arrowstyle="-", lw=0.7))
fig.suptitle("Each mini-panel: ONE policy, drifted (color) vs its own no-drift twin (gray dashed), identical noise, "
             "starting at the force-area boundary — the split is entirely inside the field", fontsize=11.5, y=1.0)
fig.tight_layout(rect=(0, 0, 1, 0.93))
fig.savefig(OUT, dpi=150)
print("saved", OUT)
