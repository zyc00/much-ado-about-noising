"""Small-multiple endgame rollouts under vision bias 0.04 for six arms:
the attr-config winners (hetero-t, MIP) fail exactly like L2 here."""
import json
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

import toyattr as T

assert T.CONFIG == "redun"
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "redun_arms_viz.png")
R = json.load(open(os.path.join(HERE, "redun_final.json")))


def rollout_traj(net, ob, g, delta, seed, ood=None, AS=8, nsteps=200):
    rng = np.random.RandomState(seed)
    p = np.array([0.0, 1.4]) + 0.05 * rng.randn(2)
    traj = [p.copy()]
    for step in range(0, nsteps, AS):
        o = torch.tensor(ob.obs(p, g, delta, rng, ood)[None], device=T.DEV)
        with torch.no_grad():
            chunk = net(o)[0].reshape(T.H, 2).cpu().numpy()
        for a in chunk[:AS]:
            p = p + np.clip(a, -T.VMAX, T.VMAX)
            traj.append(p.copy())
    return np.array(traj)


ARMS = ["l2", "hg", "ht", "mip", "gdrop", "tonly"]
NAME = {"l2": "L2", "hg": "hetero-Gauss", "ht": "hetero-t", "mip": "MIP (det anchor)",
        "gdrop": "V-dropout", "tonly": "T-only (oracle)"}
COL = {"l2": "#d62728", "hg": "#ff9896", "ht": "#9467bd", "mip": "#1f77b4",
       "gdrop": "#2ca02c", "tonly": "#17becf"}

data, ob = T.build_dataset(None, data_seed=0)
nets = {a: T.train((data, ob), a, seed=0, steps=12000) for a in ARMS}

rngG = np.random.RandomState(41)
g = rngG.uniform([-0.3, -0.3], [0.3, 0.3])
delta = rngG.uniform(0.03, 0.08) * T._unit(rngG)
tgt = g + delta
bvec = 0.04 * np.array([0.8, 0.6])
ood = {"kind": "bias", "vec": bvec}

fig, axes = plt.subplots(2, 3, figsize=(13.5, 9))
for ax, a in zip(axes.flat, ARMS):
    for s in range(6):
        traj = rollout_traj(nets[a], ob, g, delta, seed=300 + s, ood=ood)
        ax.plot(traj[:, 0], traj[:, 1], color=COL[a], lw=0.9, alpha=0.7)
    ax.add_patch(plt.Circle(tgt, T.TOL, fill=False, color="k", lw=1.4))
    ax.plot(*tgt, "kx", ms=9)
    ax.plot(*(tgt + bvec), "s", color="#c00000", ms=7)
    sr = np.mean([c["OOD"]["bias0.04"] for c in R[a]])
    tsh = np.mean([c["T_share_endgame"] for c in R[a]])
    ax.set_title(f"{NAME[a]}\nOOD SR {sr:.2f} (10 seeds) | T-share {tsh:.2f}", fontsize=10)
    m = 0.10
    ax.set_xlim(tgt[0] - m, tgt[0] + m); ax.set_ylim(tgt[1] - m, tgt[1] + m)
    ax.set_aspect("equal")
    ax.grid(alpha=0.25, lw=0.4)
axes[0, 0].annotate("true target (+ tol)", tgt, xytext=(tgt[0] - 0.09, tgt[1] - 0.06), fontsize=8)
axes[0, 0].annotate("vision-implied\nfixed point", tgt + bvec,
                    xytext=(tgt[0] + bvec[0] - 0.005, tgt[1] + bvec[1] + 0.012), fontsize=8, color="#c00000")
fig.suptitle("Endgame rollouts under vision bias 0.04 (seed-0 policies, 6 rollouts each, AS=8):\n"
             "the attr-config winners (hetero-t, MIP) settle on the corrupted vision's fixed point exactly like L2 —\n"
             "output-side levers cannot restore an input channel that training never engaged",
             y=0.99, fontsize=11)
fig.tight_layout(rect=(0, 0, 1, 0.94))
fig.savefig(OUT, dpi=150)
print("saved", OUT)
