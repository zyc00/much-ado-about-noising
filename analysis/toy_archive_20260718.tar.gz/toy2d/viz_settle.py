"""Settle-collapse figure: task schematic, hold-phase lateral drift traces
(the translate-at-settle mechanism, with slot aborts), drift-speed bars vs
the slot budget, and outcome/SR decomposition at AS=8 vs AS=1.

Trains l2/mip/flow8 (seed 0, 12k steps) with pickle cache in settle_ck_*.pt;
delete those files to force retrain. Must run with the canonical env (set
below before toyattr import)."""
import os

os.environ.setdefault("TOYCFG", "force")
os.environ.setdefault("DIMVO", "14")
os.environ.setdefault("WLO", "0")
os.environ.setdefault("WHI", "0")
os.environ.setdefault("TREMOR", "0")
os.environ.setdefault("FNOISE", "0.01")
os.environ.setdefault("EXNOISE", "0.01")
os.environ.setdefault("WIDTH", "32")
os.environ.setdefault("CLKA", "0.02")
os.environ.setdefault("CLKN", "0.004")
os.environ.setdefault("SLOT", "0.02")
os.environ.setdefault("KMIN", "20")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

import toyattr as T
import toysettle as S

COL = {"l2": "#d62728", "mip": "#1f77b4", "flow8": "#17becf"}
NAME = {"l2": "MSE", "mip": "MIP (2-step)", "flow8": "Flow (8-step)"}
ARMS = ("l2", "mip", "flow8")
SLOT = float(os.environ["SLOT"])
CLKA = float(os.environ["CLKA"])
CLKN = float(os.environ["CLKN"])

data, ob = S.build()
X, Y, W = data
print(f"dataset {len(X)} samples, near-settle frac {W.mean():.2f}", flush=True)

nets = {}
for arm in ARMS:
    ck = f"settle_ck_{arm}.pt"
    if os.path.exists(ck):
        nets[arm] = torch.load(ck, map_location=T.DEV, weights_only=False)
        print(f"{arm}: loaded cache", flush=True)
    else:
        nets[arm] = T.train(((X, Y, W), ob), arm, seed=0, steps=12000)
        torch.save(nets[arm], ck)
        print(f"{arm}: trained + cached", flush=True)


def rollout_record(net, n_ep=100, seed=999, AS=8):
    """evaluate() clone that also records hold-phase signed lateral offset
    (toward g2) per hold step, and the outcome category per episode."""
    rng = np.random.RandomState(seed)
    traces, outcomes, drifts, dirs = [], [], [], []
    for _ in range(n_ep):
        g1 = rng.uniform([-0.2, -0.2], [0.2, 0.2])
        g2 = g1 + np.array([rng.choice([-1, 1]) * rng.uniform(0.3, 0.45), 0.0])
        sgn = np.sign(g2[0] - g1[0])
        p = g1 + np.array([rng.uniform(-0.04, 0.04), 0.9])
        khold, ok, aborted = 0, False, False
        lat, dsp, dsg = [], [], []
        for step in range(0, 300, AS):
            clock = CLKA * (0.98 ** khold)
            o = torch.tensor(ob.obs(p, g1, g2, clock, rng)[None], device=T.DEV)
            with torch.no_grad():
                chunk = net(o)[0].reshape(T.H, 2).cpu().numpy()
            for a in chunk[:AS]:
                inhold = np.linalg.norm(p - g1) < 0.03 and khold < S.K_HOLD
                if khold > 0 and khold < S.K_HOLD and abs(p[0] - g1[0]) > SLOT:
                    aborted = True
                    break
                if inhold:
                    khold += 1
                    lat.append(sgn * (p[0] - g1[0]))
                    dsp.append(abs(a[0]))
                    dsg.append(sgn * a[0])
                p = p + np.clip(a, -0.15, 0.15)
                if khold >= S.KMIN and np.linalg.norm(p - g2) < 0.03:
                    ok = True
                    break
            if ok or aborted:
                break
        traces.append(np.array(lat))
        outcomes.append("success" if ok else ("abort" if aborted else "timeout"))
        if dsp:
            drifts.append(np.mean(dsp))
            dirs.append(np.mean(dsg))
    return (traces, outcomes, float(np.mean(drifts)) if drifts else float("nan"),
            float(np.mean(dirs)) if dirs else float("nan"))


rec = {}
for arm in ARMS:
    tr8, out8, dr8, di8 = rollout_record(nets[arm], AS=8)
    _, out1, dr1, di1 = rollout_record(nets[arm], AS=1)
    rec[arm] = dict(tr8=tr8, out8=out8, dr8=dr8, di8=di8, out1=out1, dr1=dr1)
    frac = {o: out8.count(o) / len(out8) for o in ("success", "abort", "timeout")}
    sr1 = out1.count("success") / len(out1)
    print(f"{arm}: AS8 {frac} |a_x| {dr8:.4f} directed {di8:+.4f} | AS1 SR {sr1:.2f}",
          flush=True)

fig = plt.figure(figsize=(13.5, 9.0))
gs = fig.add_gridspec(2, 3, height_ratios=[1.0, 1.0], hspace=0.34, wspace=0.30,
                      left=0.06, right=0.98, top=0.90, bottom=0.07)
fig.suptitle("Settle-collapse toy: time-bimodal labels on a measure-thin set "
             "→ MSE translates at settle; precision slot makes the drift fatal",
             fontsize=12.5, y=0.965)

# --- A: task schematic -------------------------------------------------------
axA = fig.add_subplot(gs[0, 0])
axA.plot([0, 0], [0.72, 0.05], color="0.55", lw=1.6)
axA.annotate("", xy=(0, 0.04), xytext=(0, 0.18),
             arrowprops=dict(arrowstyle="->", color="0.55", lw=1.6))
axA.text(0.03, 0.40, "approach", fontsize=8.5, color="0.4", rotation=90, va="center")
axA.axvspan(-SLOT, SLOT, ymin=0.30, ymax=0.52, color="tab:orange", alpha=0.45)
axA.scatter([0], [0], s=30, color="k", zorder=6)
axA.annotate("slot $\\pm0.02$ (to scale):\nleave it during the hold = abort",
             xy=(SLOT, -0.08), xytext=(0.52, -0.34), fontsize=8.5, ha="right",
             color="tab:orange", arrowprops=dict(arrowstyle="->", color="tab:orange", lw=1.2))
axA.text(-0.52, -0.24, "hold 20 steps at $g_1$\n($a=0$; timing only\nin the weak clock)",
         fontsize=8.5, color="k")
for s_ in (-1, 1):
    axA.annotate("", xy=(s_ * 0.40, 0.0), xytext=(s_ * 0.04, 0.0),
                 arrowprops=dict(arrowstyle="->", color="tab:blue", lw=1.8, alpha=0.85))
axA.scatter([-0.40, 0.40], [0, 0], s=45, color="tab:blue", zorder=5)
axA.text(0.40, 0.07, "$g_2$", fontsize=9, color="tab:blue", ha="center")
axA.text(-0.40, 0.07, "$g_2'$", fontsize=9, color="tab:blue", ha="center")
axA.text(-0.52, 0.56, "after the hold: stroke\nto $g_2$ (side observable)",
         fontsize=8.5, ha="left", va="top", color="tab:blue")
axA.text(-0.52, 0.93, "labels at the settle point are TIME-bimodal:\n"
         "hold → $a=0$   vs   go → stroke to $g_2$", fontsize=8.5, va="top")
axins = axA.inset_axes([0.68, 0.56, 0.29, 0.19])
kk = np.arange(21)
axins.fill_between(kk, CLKA * 0.98 ** kk - CLKN, CLKA * 0.98 ** kk + CLKN,
                   color="tab:green", alpha=0.3)
axins.plot(kk, CLKA * 0.98 ** kk, color="tab:green", lw=1.4)
axins.set_title("clock: $0.02{\\cdot}0.98^k \\pm 0.004$", fontsize=7)
axins.set_yticks([])
axins.tick_params(labelsize=6)
axA.set_xlim(-0.55, 0.55)
axA.set_ylim(-0.48, 0.95)
axA.set_title("A  task: approach → hold → stroke", fontsize=10, loc="left")
axA.set_xticks([])
axA.set_yticks([])

# --- B: hold-phase lateral traces (signed, toward g2) ------------------------
axB = fig.add_subplot(gs[0, 1:])
for arm in ("flow8", "mip", "l2"):  # draw MSE last so its traces stay visible
    for tr in rec[arm]["tr8"][:45]:
        if len(tr) < 2:
            continue
        axB.plot(np.arange(len(tr)), tr, color=COL[arm], alpha=0.15, lw=0.8)
for arm in ARMS:
    lens = [len(t) for t in rec[arm]["tr8"] if len(t) >= 2]
    if lens:
        kmax = int(np.median(lens))
        M = np.full((len(rec[arm]["tr8"]), kmax), np.nan)
        for i, t in enumerate(rec[arm]["tr8"]):
            n = min(len(t), kmax)
            M[i, :n] = t[:n]
        axB.plot(np.arange(kmax), np.nanmean(M, 0), color=COL[arm], lw=2.8,
                 label=NAME[arm], zorder=5)
for arm in ARMS:  # abort markers at trace ends that breached
    for tr in rec[arm]["tr8"]:
        if len(tr) >= 2 and np.abs(tr[-1]) > SLOT * 0.92:
            axB.scatter([len(tr) - 1], [tr[-1]], marker="x", s=30,
                        color=COL[arm], alpha=0.55, lw=1.2, zorder=4)
for s_ in (1, -1):
    axB.axhline(s_ * SLOT, color="tab:orange", lw=2.0)
axB.text(5.4, SLOT + 0.001, "slot edge +0.02 ($g_2$ side) — abort", fontsize=8.5,
         color="tab:orange")
axB.text(0.3, -SLOT - 0.0032, "slot edge −0.02", fontsize=8.5, color="tab:orange")
axB.annotate("MSE mean drifts TOWARD the observable\ngo-target $g_2$; episodes abort at the edge",
             xy=(9.2, 0.0105), xytext=(12.2, 0.0262), fontsize=8.5, color=COL["l2"],
             va="top", arrowprops=dict(arrowstyle="->", color=COL["l2"], lw=1.2))
axB.text(14.0, -0.017, "generative arms: zero-mean jitter,\nno directed drift",
         fontsize=8.5, color=COL["mip"],
         bbox=dict(fc="white", ec="none", alpha=0.75, pad=1.5))
axB.axhline(0, color="0.8", lw=0.8, zorder=0)
axB.set_xlabel("hold step $k$ (of 20 required)")
axB.set_ylabel("lateral offset from $g_1$, signed toward $g_2$")
axB.set_xlim(0, 21)
axB.set_ylim(-0.027, 0.027)
axB.legend(fontsize=9, loc="upper left")
axB.set_title("B  translate-at-settle, measured: hold traces (thin), mean (thick), × = slot abort",
              fontsize=10, loc="left")

# --- C: directed drift vs slot budget ---------------------------------------
axC = fig.add_subplot(gs[1, 0])
xs = np.arange(len(ARMS))
tot = [rec[a]["dr8"] for a in ARMS]
di = [rec[a]["di8"] for a in ARMS]
axC.bar(xs - 0.19, tot, 0.34, color=[COL[a] for a in ARMS], alpha=0.35,
        label="total speed  mean$|a_x|$")
axC.bar(xs + 0.19, np.abs(di), 0.34, color=[COL[a] for a in ARMS],
        label="directed drift  |mean $a_x$| (toward $g_2$)")
axC.axhline(SLOT / S.K_HOLD, color="tab:orange", lw=2.0, ls="--")
axC.annotate("slot budget 0.02/20\n= 0.001 per step", xy=(2.38, SLOT / S.K_HOLD),
             xytext=(2.45, 0.00175), fontsize=8, color="tab:orange", ha="right",
             arrowprops=dict(arrowstyle="->", color="tab:orange", lw=1.1))
for x_, v in zip(xs - 0.19, tot):
    axC.text(x_, v + 0.00006, f"{v:.4f}", ha="center", fontsize=7.5, color="0.35")
for x_, v in zip(xs + 0.19, np.abs(di)):
    axC.text(x_, v + 0.00006, f"{v:.4f}", ha="center", fontsize=7.5)
axC.set_xticks(xs, [NAME[a] for a in ARMS], fontsize=8.5)
axC.set_ylabel("hold-phase $a_x$ statistic")
axC.legend(fontsize=7.8, loc="upper right")
axC.set_title("C  directed drift vs slot budget (AS=8)", fontsize=10, loc="left")

# --- D: outcome decomposition + AS dose -------------------------------------
axD = fig.add_subplot(gs[1, 1:])
OC = {"success": "#2ca02c", "abort": "#d62728", "timeout": "0.65"}
w = 0.32
for i, arm in enumerate(ARMS):
    for j, (out, lab) in enumerate((("out8", "AS=8"), ("out1", "AS=1"))):
        oo = rec[arm][out]
        bot = 0.0
        x_ = i + (j - 0.5) * (w + 0.04)
        for cat in ("success", "abort", "timeout"):
            f_ = oo.count(cat) / len(oo)
            axD.bar(x_, f_, w, bottom=bot, color=OC[cat],
                    edgecolor="white", linewidth=0.6)
            if f_ > 0.10:
                axD.text(x_, bot + f_ / 2, f"{f_:.2f}", ha="center", va="center",
                         fontsize=7.5, color="white" if cat != "timeout" else "0.2")
            bot += f_
        axD.text(x_, -0.07, lab, ha="center", fontsize=8)
axD.set_xticks(range(len(ARMS)))
axD.set_xticklabels([NAME[a] for a in ARMS], fontsize=9.5)
axD.tick_params(axis="x", pad=20)
axD.set_ylim(0, 1.24)
axD.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
axD.set_ylabel("episode fraction")
hnd = [plt.Rectangle((0, 0), 1, 1, color=OC[c]) for c in ("success", "abort", "timeout")]
axD.legend(hnd, ["success", "slot abort (drift)", "timeout (never go / lost)"],
           fontsize=8.5, loc="upper center", ncol=3, frameon=False)
axD.set_title("D  outcomes: MSE fails by drift-abort, generative arms by holding — "
              "opposite AS dose signs", fontsize=10, loc="left")

fig.savefig("settle_fig.png", dpi=140)
print("wrote settle_fig.png", flush=True)
