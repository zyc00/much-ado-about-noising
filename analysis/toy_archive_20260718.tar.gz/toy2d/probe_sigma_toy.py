"""Why hetero-Gauss fails on the toy: per-sample sigma, residual scale, and
per-sample gradient magnitude at endgame vs reach states, for hg/ht/l2."""
import numpy as np
import torch

import toyattr as T

data, ob = T.build_dataset(None, data_seed=0)
X, Y, W = data
Xt = torch.tensor(X, device=T.DEV)
Yt = torch.tensor(Y, device=T.DEV)
sel_e = torch.tensor(W, device=T.DEV)
K = 2 * T.H

for loss in ("l2", "hg", "ht"):
    net = T.train((data, ob), loss, seed=0, steps=12000)
    pred, sraw = net(Xt)
    pred = pred.detach().requires_grad_(True)
    sig = torch.nn.functional.softplus(sraw.detach()) + 1e-3
    r2 = ((pred - Yt) ** 2).sum(dim=1)
    if loss == "hg":
        per = 0.5 * r2 / sig ** 2 + K * torch.log(sig)
    elif loss == "ht":
        nu = 3.0
        z2 = r2 / (sig ** 2 * K)
        per = 0.5 * (nu + K) * torch.log1p(z2 * K / nu) + K * torch.log(sig)
    else:
        per = r2
    g = torch.autograd.grad(per.sum(), pred)[0].norm(dim=1)
    rms = (r2 / K).sqrt()
    e, r = sel_e, ~sel_e
    print(f"{loss}: sigma end/reach {sig[e].mean():.4f}/{sig[r].mean():.4f} | "
          f"resid-RMS end/reach {rms[e].mean():.4f}/{rms[r].mean():.4f} | "
          f"grad|pred end/reach {g[e].mean():.4f}/{g[r].mean():.4f} | "
          f"endgame grad share {g[e].sum() / g.sum():.3f} (count share {e.float().mean():.3f})",
          flush=True)
