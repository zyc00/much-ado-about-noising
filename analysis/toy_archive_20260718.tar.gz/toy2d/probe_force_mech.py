"""Mechanism decomposition: cancellation gain (da_x/df_x, functional sensor
use; -1 = perfect cancel) vs effective servo gain (park test: constant push
0.02 with sensor withheld; K_eff = push/offset)."""
import numpy as np
import torch

import toyattr as T

data, ob = T.build_dataset(None, data_seed=0)
X, Y, W = data


def cancel_gain(net):
    xs = torch.tensor(X[W][:256], device=T.DEV, requires_grad=True)
    a1x = net.chunk_from_obs(xs)[:, 0]
    g = torch.autograd.grad(a1x.sum(), xs)[0]
    return float(g[:, 12].mean())


def park_test(net, push=0.02, n=40):
    offs = []
    rng = np.random.RandomState(7)
    for i in range(n):
        g = rng.uniform([-0.3, -0.3], [0.3, 0.3])
        p = g + 0.03 * T._unit(rng)
        for step in range(60):
            fs = T.FNOISE * rng.randn(2)
            o = torch.tensor(ob.obs(p, g, np.zeros(2), rng, None, f=fs)[None], device=T.DEV)
            with torch.no_grad():
                a = net(o)[0].reshape(T.H, 2).cpu().numpy()[0]
            p = p + np.clip(a, -T.DCLIP, T.DCLIP) + T.field(p, g, np.zeros(2)) + np.array([push, 0.0])
        offs.append(abs(p[0] - g[0]))
    off = np.median(offs)
    return off, push / max(off, 1e-6)


import os as _os
CASES = [("mip", 9, "shift-robust, low-engagement"), ("mip", 1, "engaged, shift-dead"),
         ("l2", 7, "no-engagement, shift 0.34"), ("l2", 0, "captured baseline"),
         ("hg", 0, "high-engagement, shift-dead"), ("pdropf", 0, "the sensor cure")]
for arm, seed, note in CASES:
    if arm == "pdropf":
        _os.environ["PDROP"] = "0.9"
    net = T.train((data, ob), arm, seed=seed, steps=12000)
    cg = cancel_gain(net)
    off, keff = park_test(net)
    print(f"{arm} s{seed} ({note}): cancel-gain {cg:+.2f} | park offset {off:.3f} -> K_eff {keff:.2f}", flush=True)
