"""Gradient-SNR probe: per-pathway (force vs position input columns) minibatch
gradient signal ||mean_g|| vs noise sqrt(E||g-mean||^2) for l2 vs flow."""
import numpy as np
import torch

import toyattr as T

data, ob = T.build_dataset(None, data_seed=0)
X, Y, W = data


def grad_stats(loss_name, warm, nb=64, seed=0):
    torch.manual_seed(seed)
    net = (T.MipNet(X.shape[1]) if loss_name == "flow8" else T.Net(X.shape[1], dim_v=T.DIMV)).to(T.DEV)
    if loss_name == "flow8":
        net.nsteps = 8
    Xt = torch.tensor(X, device=T.DEV); Yt = torch.tensor(Y, device=T.DEV)
    net.set_norm(X.min(0), X.max(0), Y.min(0), Y.max(0)) if hasattr(net, "set_norm") else None
    if loss_name == "flow8":
        net.ymu.copy_(Yt.mean(0)); net.ysd.copy_(Yt.std(0) + 1e-6)
    opt = torch.optim.Adam(net.parameters(), lr=1e-3)
    rng = np.random.RandomState(seed)

    def one_loss(idx):
        xb, yb = Xt[idx], Yt[idx]
        if loss_name == "flow8":
            yn = (yb - net.ymu) / net.ysd
            eps = torch.randn_like(yn)
            tt = torch.rand(len(yn), 1, device=T.DEV)
            ytt = (1 - tt) * eps + tt * yn
            v = net.vel(xb, ytt, tt)
            return ((v - (yn - eps)) ** 2).sum(dim=1).mean()
        pred, _ = net._fwd_norm(xb)
        ybn = (yb - net.yc) / net.ys
        return ((pred - ybn) ** 2).sum(dim=1).mean()

    for it in range(warm):
        idx = rng.randint(0, len(Xt), 256)
        l = one_loss(idx)
        opt.zero_grad(); l.backward(); opt.step()

    W1 = net.f[0].weight
    grads = []
    for _ in range(nb):
        idx = rng.randint(0, len(Xt), 256)
        l = one_loss(idx)
        opt.zero_grad(); l.backward()
        grads.append(W1.grad.detach()[:, :].clone())
    G = torch.stack(grads)
    gm = G.mean(0)
    gn = (G - gm).pow(2).mean(0).sqrt()
    dv = T.DIMV
    out = {}
    for name, sl in (("pos", slice(0, dv)), ("force", slice(dv, dv + 2))):
        sig = float(gm[:, sl].norm())
        noi = float(gn[:, sl].norm())
        out[name] = (sig, noi, sig / (noi + 1e-12))
    return out


for loss in ("l2", "flow8"):
    for warm in (200, 1000, 4000):
        st = grad_stats(loss, warm)
        print(f"{loss:6s} @step {warm:5d}: "
              f"pos sig/noise/SNR = {st['pos'][0]:.4f}/{st['pos'][1]:.4f}/{st['pos'][2]:.2f} | "
              f"force = {st['force'][0]:.4f}/{st['force'][1]:.4f}/{st['force'][2]:.2f}", flush=True)
