"""Gated-vs-shared sensor gain: cancel gain measured separately at in-strip
and out-strip states for l2 vs flow."""
import numpy as np
import torch

import toyattr as T

data, ob = T.build_dataset(None, data_seed=0)
X, Y, W = data
outmask = ~W


def gain_at(net, mask):
    xs = torch.tensor(X[mask][:256], device=T.DEV, requires_grad=True)
    a1x = net.chunk_from_obs(xs)[:, 0]
    g = torch.autograd.grad(a1x.sum(), xs)[0]
    return float(g[:, 12].mean())


for arm in ("l2", "flow8"):
    for seed in (0, 1):
        net = T.train((data, ob), arm, seed=seed, steps=12000)
        gi = gain_at(net, W)
        go = gain_at(net, outmask)
        print(f"{arm} s{seed}: sensor gain IN-strip {gi:+.2f} | OUT-strip {go:+.2f} | gate ratio {abs(gi)/max(abs(go),1e-6):.1f}", flush=True)
