"""Config "fold" (scripted-regime analog): approach -> hover(latch ramps,
near-zero actions) -> lateral stroke. The latch (small-amplitude channel) is
the only feature separating hover from stroke-onset at the same position.
Pre-registered: L2 starves/folds it (premature-translate during hover, SR
collapse); hetero/MIP/flow reprice the quiet phase and keep it (SR high).

Env knobs: ALATCH TH TREMOR RARR RHOLD  (plus toyattr's WIDTH/NEP/STEPS)
Usage: TOYCFG=fold DIMVO=14 python toyfold.py --losses l2,ht --seeds 2
"""
import argparse
import json
import os

import numpy as np
import torch

import toyattr as T

ALATCH = float(os.environ.get("ALATCH", "0.03"))
TH = int(os.environ.get("TH", "15"))
TREMOR = float(os.environ.get("TREMOR", "0.008"))
RARR = float(os.environ.get("RARR", "0.06"))
RHOLD = float(os.environ.get("RHOLD", "0.05"))
RAMP = int(os.environ.get("RAMP", "24"))
LNOISE = float(os.environ.get("LNOISE", "0.003"))
KS, VMAX, H = 0.25, 0.15, T.H
STROKE_TOL, STROKE_HOLD = 0.03, 5


class FoldObs:
    def __init__(self, seed=0):
        r = np.random.RandomState(seed)
        self.Wp = r.randn(6, 2) / np.sqrt(2)
        self.Wh = r.randn(4, 2) / np.sqrt(2)
        self.Wt = r.randn(4, 2) / np.sqrt(2)
        self.dim_v, self.dim_t = 14, 1

    def obs(self, p, h, t, latch, rng):
        v = np.concatenate([self.Wp @ p, self.Wh @ h, self.Wt @ (t - h)]) + 0.005 * rng.randn(14)
        l = np.array([latch * ALATCH]) + LNOISE * rng.randn(1)
        return np.concatenate([v, l]).astype(np.float32)


def gen_episode(rng):
    h = rng.uniform([-0.2, -0.2], [0.2, 0.2])
    t = h + np.array([rng.choice([-1, 1]) * rng.uniform(0.35, 0.5), 0.0])
    p = h + np.array([rng.uniform(-0.05, 0.05), 0.8 + rng.uniform(-0.05, 0.05)])
    latch = 0.0
    ps, acts, ls = [], [], []
    held, kst, arrived, aborted = 0, 0, False, False
    for _ in range(240):
        near = np.linalg.norm(p - h) < RARR
        if latch < 1.0 and near:
            latch = min(1.0, latch + 1.0 / TH)
            arrived = True
            a = np.zeros(2)
        elif latch < 1.0:
            a = np.clip(KS * (h - p), -VMAX, VMAX)
        else:
            kst += 1
            a = np.clip(KS * (t - p), -VMAX, VMAX) * min(1.0, kst / RAMP)
        a = a + TREMOR * rng.standard_t(3, 2)
        ps.append(p.copy()); acts.append(a.copy()); ls.append(latch)
        p = p + a
        if arrived and latch < 1.0 and np.linalg.norm(p - h) > RHOLD:
            aborted = True
            break
        if latch >= 1.0 and np.linalg.norm(p - t) < STROKE_TOL:
            held += 1
            if held >= STROKE_HOLD + 3:
                break
        else:
            held = 0
    return np.array(ps), np.array(acts), np.array(ls), h, t, aborted


def build_dataset(n_ep=None):
    n_ep = n_ep or T.NEP
    rng = np.random.RandomState(0)
    ob = FoldObs(seed=123)
    X, Y, W = [], [], []
    kept = 0
    while kept < n_ep:
        ps, acts, ls, h, t, aborted = gen_episode(rng)
        if aborted:
            continue
        kept += 1
        obs = np.array([ob.obs(p, h, t, l, rng) for p, l in zip(ps, ls)])
        quiet = np.array([(l < 1.0) and (np.linalg.norm(p - h) < RARR)
                          for p, l in zip(ps, ls)])
        for k in range(len(ps) - H):
            X.append(obs[k]); Y.append(acts[k:k + H].reshape(-1)); W.append(quiet[k])
    return (np.array(X, dtype=np.float32), np.array(Y, dtype=np.float32),
            np.array(W)), ob


def rollout(net, ob, n_ep=100, AS=8, seed=999):
    rng = np.random.RandomState(seed)
    succ, drifts, latchdone = 0, [], 0
    for _ in range(n_ep):
        h = rng.uniform([-0.2, -0.2], [0.2, 0.2])
        t = h + np.array([rng.choice([-1, 1]) * rng.uniform(0.35, 0.5), 0.0])
        p = h + np.array([rng.uniform(-0.05, 0.05), 0.8 + rng.uniform(-0.05, 0.05)])
        latch, held, ok, maxdrift = 0.0, 0, False, 0.0
        arrived, aborted = False, False
        for step in range(0, 240, AS):
            o = torch.tensor(ob.obs(p, h, t, latch, rng)[None], device=T.DEV)
            with torch.no_grad():
                chunk = net(o)[0].reshape(H, 2).cpu().numpy()
            for a in chunk[:AS]:
                near = np.linalg.norm(p - h) < RARR
                if latch < 1.0 and near:
                    latch = min(1.0, latch + 1.0 / TH)
                    arrived = True
                if arrived and latch < 1.0:
                    maxdrift = max(maxdrift, np.linalg.norm(p - h))
                    if maxdrift > RHOLD:
                        aborted = True; break
                p = p + np.clip(a, -VMAX, VMAX)
                if latch >= 1.0 and np.linalg.norm(p - t) < STROKE_TOL:
                    held += 1
                    if held >= STROKE_HOLD:
                        ok = True; break
                else:
                    held = 0
            if ok or aborted:
                break
        succ += int(ok)
        latchdone += int(latch >= 1.0)
        drifts.append(maxdrift)
    return succ / n_ep, latchdone / n_ep, float(np.median(drifts))


def latch_share(net, X, sel):
    xs = torch.tensor(X[sel][:64], device=T.DEV, requires_grad=True)
    pred = net.chunk_from_obs(xs)
    gL = gV = 0.0
    for k in range(0, 2 * H, 4):
        g = torch.autograd.grad(pred[:, k].sum(), xs, retain_graph=True)[0]
        gV += float((g[:, :14] ** 2).sum()); gL += float((g[:, 14:] ** 2).sum())
    return gL / (gL + gV + 1e-12)


def fold_probe(net, ob):
    """Pairs at the SAME hover position differing only in latch (0.3 vs 1.0).
    Feature sensitivity vs a matched-norm position move; action separation
    as fraction of the oracle stroke command."""
    rng = np.random.RandomState(5)
    o1, o2, o3, oracle = [], [], [], []
    dl = 0.7 * ALATCH
    for _ in range(128):
        h = rng.uniform([-0.2, -0.2], [0.2, 0.2])
        t = h + np.array([rng.choice([-1, 1]) * rng.uniform(0.35, 0.5), 0.0])
        a1 = ob.obs(h, h, t, 0.3, np.random.RandomState(7))
        a2 = a1.copy(); a2[14] = 1.0 * ALATCH + LNOISE * np.random.RandomState(8).randn()
        a3 = ob.obs(h + np.array([dl, 0]), h, t, 0.3, np.random.RandomState(7)); a3[14] = a1[14]
        o1.append(a1); o2.append(a2); o3.append(a3)
        oracle.append(np.linalg.norm(np.clip(KS * (t - h), -VMAX, VMAX)))
    O1 = torch.tensor(np.array(o1), device=T.DEV)
    O2 = torch.tensor(np.array(o2), device=T.DEV)
    O3 = torch.tensor(np.array(o3), device=T.DEV)
    with torch.no_grad():
        z1, z2, z3 = net.features(O1), net.features(O2), net.features(O3)
        c1 = net.chunk_from_obs(O1).reshape(-1, H, 2)
        c2 = net.chunk_from_obs(O2).reshape(-1, H, 2)
    st = (z2 - z1).norm(dim=1).cpu().numpy() / dl
    sv = (z3 - z1).norm(dim=1).cpu().numpy() / dl
    da = (c2[:, 0] - c1[:, 0]).norm(dim=1).cpu().numpy()
    sep = da / np.array(oracle)
    return float(st.mean() / (sv.mean() + 1e-9)), float(np.mean(sep))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--losses", default="l2,hg,ht,mip")
    ap.add_argument("--seeds", type=int, default=2)
    ap.add_argument("--out", default="")
    args = ap.parse_args()
    data, ob = build_dataset()
    X, Y, W = data
    print(f"dataset: {len(X)} samples, quiet frac {W.mean():.2f}", flush=True)
    res = {}
    for loss in args.losses.split(","):
        cells = []
        for s in range(args.seeds):
            net = T.train(((X, Y, W), ob), loss, seed=s)
            ls = latch_share(net, X, W)
            fr, sep = fold_probe(net, ob)
            sr, ld, dr = rollout(net, ob)
            cells.append({"seed": s, "latch_share": ls, "fold_featratio": fr,
                          "action_sep": sep, "SR": sr, "latch_done": ld, "drift": dr})
            print(f"{loss} s{s}: latch-share {ls:.3f} | fold-ratio {fr:.2f} "
                  f"action-sep {sep:.2f} | SR {sr:.2f} latch-done {ld:.2f} drift {dr:.3f}", flush=True)
        res[loss] = cells
        m = lambda k: np.mean([c[k] for c in cells])
        sd = np.std([c["SR"] for c in cells])
        print(f"== {loss}: latch-share {m('latch_share'):.3f} fold-ratio {m('fold_featratio'):.2f} "
              f"action-sep {m('action_sep'):.2f} | SR {m('SR'):.2f}±{sd:.2f} "
              f"latch-done {m('latch_done'):.2f} drift {m('drift'):.3f}", flush=True)
    if args.out:
        json.dump(res, open(args.out, "w"), default=float)
    print("FOLD-DONE")


if __name__ == "__main__":
    main()
