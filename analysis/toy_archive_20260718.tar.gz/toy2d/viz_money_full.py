"""Slide-ready two-panel money figure: L2 fails under drift, feature-keeping
losses don't. Uses the FNOISE=0.005 showcase point."""
import glob
import json
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

import toyattr as T

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "money_fig.png")

ARMS = ["l2", "ht", "hg", "mip", "flow8"]
NAME = {"l2": "L2 (MSE)", "ht": "hetero-t", "hg": "hetero-G", "mip": "MIP", "flow8": "Flow"}
COL = {"l2": "#d62728", "ht": "#9467bd", "hg": "#ff9896", "mip": "#1f77b4", "flow8": "#17becf"}


def load_cells(arm):
    cells = []
    for f in ("force_norm_final.json",):
        p = os.path.join(HERE, f)
        if os.path.exists(p):
            cells += json.load(open(p)).get(arm, [])
    seen, out = set(), []
    for c in cells:
        if c["seed"] not in seen:
            seen.add(c["seed"]); out.append(c)
    return out


R = {a: load_cells(a) for a in ARMS}
fig = plt.figure(figsize=(15.5, 10.8))
gs = fig.add_gridspec(2, 15, height_ratios=[0.95, 1.1], wspace=1.1, hspace=0.32)


def _crossings(shift):
    xs = np.linspace(-T.RF + 1e-3, T.RF - 1e-3, 2000)
    fv = T.FA * (np.sin(T.FW * xs) + T.FC) + shift
    return [xs[i] for i in range(len(xs) - 1) if fv[i] * fv[i + 1] < 0]


def draw_field_panel(ax, shift, title, show_ghost=False, show_demo=False):
    grid = np.linspace(-0.33, 0.33, 400)
    X, Y = np.meshgrid(grid, grid)
    F = T.FA * (np.sin(T.FW * X) + T.FC) + shift
    Z = np.where(X ** 2 + Y ** 2 <= T.RF ** 2, F, np.nan)
    ax.imshow(Z, origin="lower", extent=(-0.33, 0.33, -0.33, 0.33),
              cmap="bwr", vmin=-0.13, vmax=0.13, interpolation="bilinear", zorder=0)
    ax.add_patch(plt.Circle((0, 0), T.RF, fill=False, ls="--", color="0.35", lw=1.5))
    for xc in _crossings(shift):
        if xc < -0.15:
            continue
        h = np.sqrt(max(T.RF ** 2 - xc ** 2, 0))
        ax.plot([xc, xc], [-h, h], "k-", lw=2.2, zorder=3)
    if show_ghost:
        olds = [c for c in _crossings(0.0) if c > -0.15]
        news = [c for c in _crossings(shift) if c > -0.15]
        for xc_old, xc_new in zip(olds, news):
            h = np.sqrt(max(T.RF ** 2 - xc_old ** 2, 0))
            ax.plot([xc_old, xc_old], [-h, h], color="0.45", lw=1.6, ls=":", zorder=3)
            ax.annotate("", xy=(xc_new, 0.13), xytext=(xc_old, 0.13),
                        arrowprops=dict(arrowstyle="->", color="k", lw=1.5))
    for yy in (-0.17, -0.02, 0.13):
        half = np.sqrt(max(T.RF ** 2 - yy ** 2, 0)) - 0.02
        for xx in np.linspace(-0.23, 0.23, 12):
            if abs(xx) < half:
                f = T.FA * (np.sin(T.FW * xx) + T.FC) + shift
                ln = f * 1.4
                ln = np.clip(ln, -half - xx, half - xx)
                if abs(ln) < 0.008:
                    continue
                ax.arrow(xx, yy, ln, 0, head_width=0.011, head_length=0.010,
                         color="#c00000" if f > 0 else "#1f4fc0", alpha=0.85, lw=0.6, zorder=2)
    if show_demo:
        for x0 in (-0.06, 0.14):
            p = np.array([x0, 0.42])
            tr = [p.copy()]
            for _ in range(50):
                f = np.array([T.FA * (np.sin(T.FW * p[0]) + T.FC), 0.0]) if np.linalg.norm(p) < T.RF else np.zeros(2)
                a = np.clip(0.25 * (-p), -0.15, 0.15) - f
                p = p + a + f
                tr.append(p.copy())
                if np.linalg.norm(p) < 0.012:
                    break
            tr = np.array(tr)
            ax.plot(tr[:, 0], tr[:, 1], color="tab:blue", lw=1.8, alpha=0.9, zorder=4)
        ax.text(-0.325, 0.385, "expert demos: read the sensor,\ncancel the force -> straight in", fontsize=8.5, color="tab:blue")
    ax.plot(0, 0, "kx", ms=11, mew=2.5, zorder=5)
    ax.text(0.014, -0.045, "target g", fontsize=9)
    ax.text(-0.315, -0.315, "NO force out here", fontsize=8.5, color="0.35")
    ax.text(-0.135, 0.335, "push left", fontsize=8.5, color="#1f4fc0", ha="center")
    ax.text(0.12, 0.335, "push right", fontsize=8.5, color="#c00000", ha="center")
    ax.set_xlim(-0.33, 0.38); ax.set_ylim(-0.33, 0.44)
    ax.set_xticks([]); ax.set_yticks([])
    ax.set_aspect("equal")
    ax.set_title(title, fontsize=11)


axA = fig.add_subplot(gs[0, 0:5])
draw_field_panel(axA, 0.0, "A. Training: a force field acts ONLY inside the circle;\nblack lines = where the force flips direction.\nThe expert cancels it by READING THE SENSOR", show_demo=True)
axB = fig.add_subplot(gs[0, 5:10])
draw_field_panel(axB, 0.02, "B. Deployment: the field drifts (+0.02) — the flip\nlines MOVE (dotted -> solid) and every arrow changes;\nmemorized cancellation is wrong, the sensor still true", show_ghost=True)


axT = fig.add_subplot(gs[0, 10:15])
axT.axis("off")
rows = []
rcolors = []
for a in ARMS:
    fs = np.mean([c["F_share"] for c in R[a]])
    idn = np.mean([c["normal"] for c in R[a]])
    dr = np.mean([c["shift0.02"] for c in R[a]])
    rows.append([NAME[a], f"{fs:.0%} / {1 - fs:.0%}", f"{idn:.2f}", f"{dr:.2f}"])
    rcolors.append(COL[a])
tbl = axT.table(cellText=rows, colLabels=["method", "force/pos\nreliance", "SR\n(training)", "SR\n(drifted)"],
                loc="center", cellLoc="center", bbox=[0, 0.08, 1, 0.8])
tbl.auto_set_font_size(False)
tbl.set_fontsize(10.5)
for k in range(4):
    tbl[0, k].set_facecolor("0.92")
    tbl[0, k].set_height(0.16)
for r_ in range(1, len(rows) + 1):
    tbl[r_, 0].get_text().set_color(rcolors[r_ - 1])
    tbl[r_, 0].get_text().set_fontweight("bold")
    if rows[r_ - 1][0] == "L2 (MSE)":
        for k in range(4):
            tbl[r_, k].set_facecolor("#fdeaea")
axT.set_title("The mixture decides deployment:\nmore force reliance -> higher drifted SR", fontsize=11)

# ===================== BOTTOM ROW: the result =====================
ax = fig.add_subplot(gs[1, 0:6])

x = np.arange(len(ARMS))
id_sr = [np.mean([c["normal"] for c in R[a]]) for a in ARMS]
dr_sr = [np.mean([c["shift0.02"] for c in R[a]]) for a in ARMS]
dr_sd = [np.std([c["shift0.02"] for c in R[a]]) for a in ARMS]
w = 0.38
ax.bar(x - w / 2, id_sr, w, color="0.6", label="training conditions")
ax.bar(x + w / 2, dr_sr, w, color=[COL[a] for a in ARMS], yerr=dr_sd,
       error_kw=dict(lw=1, capsize=3), label="deployment (field drifted)")
for i in range(len(ARMS)):
    ax.text(x[i] + w / 2, dr_sr[i] + 0.035, f"{dr_sr[i]:.2f}", ha="center",
            fontsize=12, fontweight="bold")
ax.set_xticks(x); ax.set_xticklabels([NAME[a] for a in ARMS], fontsize=10.5)
ax.set_ylabel("success rate", fontsize=12)
ax.set_ylim(0, 1.18)
ax.legend(fontsize=10, loc="lower right")
ax.set_title("C. Near-identical in training; the regression family collapses at\n"
             "deployment (F-share 0.28-0.47 vs generative 0.67-0.68)", fontsize=11.5)
ax.grid(alpha=0.25, lw=0.4, axis="y")

data, ob = T.build_dataset(None, data_seed=0)
gg = np.array([0.1, -0.05]); sv = np.array([0.02, 0.0])
l2_seed = min(R["l2"], key=lambda c: c["shift0.02"])["seed"]


def roll(net, seed, drifted):
    rng = np.random.RandomState(seed)
    p = np.array([0.079, 0.25]) + 0.02 * rng.randn(2)
    traj = [p.copy()]
    dv = sv if drifted else np.zeros(2)
    for step in range(160):
        f_app = T.field(p, gg, np.zeros(2)) + (dv if np.linalg.norm(p - gg) < T.RF else 0.0)
        o = torch.tensor(ob.obs(p, gg, np.zeros(2), rng, None, f=f_app)[None], device=T.DEV)
        with torch.no_grad():
            act = net(o)[0].reshape(T.H, 2).cpu().numpy()[0]
        p = p + np.clip(act, -T.DCLIP, T.DCLIP) + f_app
        traj.append(p.copy())
    return np.array(traj)


VERDICT = {"l2": "leaves its baseline\n-> misses", "mip": "stays on baseline\n-> holds",
           "flow8": "stays on baseline\n-> holds"}
for k, a in enumerate(("l2", "mip", "flow8")):
    axm = fig.add_subplot(gs[1, 6 + 3 * k:9 + 3 * k])
    ck = os.path.join(HERE, f"cache_money_{a}.pt")
    if os.path.exists(ck):
        net = (T.MipNet(14) if a in ("mip", "flow8") else T.Net(14, dim_v=T.DIMV)).to(T.DEV)
        if a == "flow8":
            net.nsteps = 8
        net.load_state_dict(torch.load(ck))
    else:
        net = T.train((data, ob), a, seed=l2_seed if a == "l2" else 0, steps=12000)
        torch.save(net.state_dict(), ck)
    for s_ in range(3):
        tb = roll(net, 500 + s_, False)
        td = roll(net, 500 + s_, True)
        axm.plot(tb[:, 0], tb[:, 1], color="0.45", lw=1.3, ls="--", alpha=0.8,
                 label="no drift" if s_ == 0 else None)
        axm.plot(td[:, 0], td[:, 1], color=COL[a], lw=1.7, alpha=0.9,
                 label="drifted field" if s_ == 0 else None)
    axm.add_patch(plt.Circle(gg, T.RF, fill=False, ls="--", color="tab:red", lw=1.2))
    axm.add_patch(plt.Circle(gg, 0.045, fill=False, color="k", lw=1.6))
    axm.plot(*gg, "kx", ms=9, mew=2)
    axm.set_xlim(gg[0] - 0.22, gg[0] + 0.22); axm.set_ylim(gg[1] - 0.2, gg[1] + 0.33)
    axm.set_aspect("equal")
    axm.set_xticks([]); axm.set_yticks([])
    axm.set_title(f"{NAME[a]}: {VERDICT[a]}", fontsize=11, color=COL[a])
    if k == 0:
        axm.legend(fontsize=8.5, loc="lower left")
        axm.annotate("start: entering\nthe force area", (0.079, 0.25), xytext=(gg[0] - 0.21, gg[1] + 0.19),
                     fontsize=8.5, arrowprops=dict(arrowstyle="-", lw=0.7))
fig.suptitle("A policy that ignores its force sensor is invisible in training and broken at deployment — generative objectives\n"
             "(MIP/Flow) keep the sensor engaged; regression objectives (MSE, hetero) largely drop it  [all inputs/outputs min-max normalized]",
             fontsize=12.5, y=0.995)
fig.text(0.655, 0.035, "D. one policy per panel: drifted (color) vs its own no-drift twin (gray dashed), identical noise,\n"
         "starting at the force-area boundary — the split is entirely inside the field",
         fontsize=10.5, ha="center")
OUT2 = os.path.join(HERE, "money_full.png")
fig.savefig(OUT2, dpi=150, bbox_inches="tight")
print("saved", OUT2)
