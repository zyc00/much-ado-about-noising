"""Does MSE's in-strip sensor gain creep upward at very long horizons
(slow gating) or stay truly flat (stalled)?"""
import numpy as np
import torch

import toyattr as T

data, ob = T.build_dataset(None, data_seed=0)
X, Y, W = data
Xt = torch.tensor(X, device=T.DEV); Yt = torch.tensor(Y, device=T.DEV)


def gains(net):
    out = []
    for mask in (W, ~W):
        xs = torch.tensor(X[mask][:256], device=T.DEV, requires_grad=True)
        a1x = net.chunk_from_obs(xs)[:, 0]
        g = torch.autograd.grad(a1x.sum(), xs)[0]
        out.append(float(g[:, 12].mean()))
    return out


torch.manual_seed(0)
net = T.Net(X.shape[1], dim_v=T.DIMV).to(T.DEV)
net.set_norm(X.min(0), X.max(0), Y.min(0), Y.max(0))
opt = torch.optim.Adam(net.parameters(), lr=1e-3)
rng = np.random.RandomState(0)
for it in range(1, 240001):
    idx = rng.randint(0, len(Xt), 256)
    xb, yb = Xt[idx], Yt[idx]
    pred, _ = net._fwd_norm(xb)
    ybn = (yb - net.yc) / net.ys
    l = ((pred - ybn) ** 2).sum(dim=1).mean()
    opt.zero_grad(); l.backward(); opt.step()
    if it in (12000, 60000, 120000, 180000, 240000):
        gi, go = gains(net)
        print(f"l2 @{it:6d}: in-strip gain {gi:+.3f} | out-strip {go:+.3f} | gate ratio {abs(gi)/max(abs(go),1e-6):.1f}", flush=True)
