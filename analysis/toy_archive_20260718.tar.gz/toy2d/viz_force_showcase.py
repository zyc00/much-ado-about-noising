"""Showcase figure (FNOISE=0.005): L2 half-abandons the force sensor and
fails under calibration drift; hetero/MIP/flow keep it engaged and survive.
Panels: A headline bars (F-share + shift SR), B policy rollouts under shift,
C engagement->SR scatter, D the sensor-noise regime curves."""
import glob
import json
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

import toyattr as T

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "force_showcase.png")

ARMS = ["l2", "ht", "hg", "mip", "flow8", "adp"]
NAME = {"l2": "L2", "ht": "hetero-t", "hg": "hetero-G", "mip": "MIP (2-step)",
        "flow8": "Flow (8-step)", "adp": "per-modality\n+dropout"}
COL = {"l2": "#d62728", "ht": "#9467bd", "hg": "#ff9896", "mip": "#1f77b4",
       "flow8": "#17becf", "adp": "#2ca02c"}


def load_cells(arm):
    cells = []
    for f in ("sweep_fn0.005.json", "force_fn005_extra.json", "force_fn005_s3to5.json"):
        p = os.path.join(HERE, f)
        if os.path.exists(p):
            d = json.load(open(p))
            cells += d.get(arm, [])
    seen, out = set(), []
    for c in cells:
        if c["seed"] not in seen:
            seen.add(c["seed"]); out.append(c)
    return out


R = {a: load_cells(a) for a in ARMS}
mean = lambda a, k: np.mean([c[k] for c in R[a]])
std = lambda a, k: np.std([c[k] for c in R[a]])

fig, axes = plt.subplots(2, 2, figsize=(13.5, 10.5))

# --- A: headline bars -------------------------------------------------------
ax = axes[0, 0]
x = np.arange(len(ARMS)); w = 0.38
fs = [mean(a, "F_share") for a in ARMS]
sr = [mean(a, "shift0.02") for a in ARMS]
ax.bar(x - w / 2, fs, w, color="0.55", label="force feature kept (F-share)")
ax.bar(x + w / 2, sr, w, color=[COL[a] for a in ARMS],
       yerr=[std(a, "shift0.02") for a in ARMS], error_kw=dict(lw=0.9, capsize=2),
       label="SR under calibration drift (shift 0.02)")
for i, a in enumerate(ARMS):
    ax.text(x[i] + w / 2, sr[i] + 0.03, f"{sr[i]:.2f}", ha="center", fontsize=9)
ax.set_xticks(x); ax.set_xticklabels([NAME[a] for a in ARMS], fontsize=8.5)
ax.set_ylim(0, 1.18)
ax.legend(fontsize=8.5, loc="upper left")
ax.set_title("A. Same task, same data: L2 keeps less of the force feature and\n"
             "collapses under drift; hetero/MIP/Flow keep it and survive")

# --- B: rollouts under shift ------------------------------------------------
axB = axes[0, 1]
data, ob = T.build_dataset(None, data_seed=0)
os.environ["PDROP"] = "0.9"
gg = np.array([0.1, -0.05]); sv = np.array([0.02, 0.0])
for a in ARMS:
    net = T.train((data, ob), a, seed=0, steps=12000)
    for s in range(4):
        rng = np.random.RandomState(500 + s)
        p = np.array([0.0, 1.4]) + 0.05 * rng.randn(2)
        traj = [p.copy()]
        for step in range(200):
            f_app = T.field(p, gg, np.zeros(2)) + (sv if np.linalg.norm(p - gg) < T.RF else 0.0)
            o = torch.tensor(ob.obs(p, gg, np.zeros(2), rng, None, f=f_app)[None], device=T.DEV)
            with torch.no_grad():
                act = net(o)[0].reshape(T.H, 2).cpu().numpy()[0]
            p = p + np.clip(act, -T.DCLIP, T.DCLIP) + f_app
            traj.append(p.copy())
        traj = np.array(traj)
        axB.plot(traj[:, 0], traj[:, 1], color=COL[a], lw=0.9, alpha=0.65,
                 label=NAME[a].replace("\n", " ") if s == 0 else None)
axB.add_patch(plt.Circle(gg, 0.045, fill=False, color="k", lw=1.4))
axB.plot(*gg, "kx", ms=9)
m = 0.13
axB.set_xlim(gg[0] - m, gg[0] + m); axB.set_ylim(gg[1] - m, gg[1] + m)
axB.legend(fontsize=7.5, loc="upper left")
axB.set_aspect("equal")
axB.set_title("B. Rollouts under drift (seed-0 policies): L2 (red) parks outside\n"
              "the tolerance; every feature-keeping policy settles on the target")

# --- C: engagement -> SR scatter -------------------------------------------
ax = axes[1, 0]
for a in ARMS:
    xs = [c["F_share"] for c in R[a]]
    ys = [c["shift0.02"] for c in R[a]]
    ax.scatter(xs, ys, s=42, color=COL[a], label=NAME[a].replace("\n", " "),
               edgecolor="white", linewidth=0.5)
allx = [c["F_share"] for a in ARMS for c in R[a]]
ally = [c["shift0.02"] for a in ARMS for c in R[a]]
r = np.corrcoef(allx, ally)[0, 1]
ax.set_xlabel("force-feature share (Jacobian mass, in-distribution)")
ax.set_ylabel("SR under calibration drift")
ax.set_title(f"C. Feature kept -> deployment success, per seed (r = {r:+.2f})")
ax.legend(fontsize=7.5, loc="lower right")

# --- D: regime curves -------------------------------------------------------
ax = axes[1, 1]
fns = [0.005, 0.01, 0.015, 0.02]
for a, c in (("l2", "#d62728"), ("mip", "#1f77b4")):
    ys, es = [], []
    for fn in fns:
        p = os.path.join(HERE, f"sweep_fn{fn:g}.json")
        d = json.load(open(p))
        v = [abs(x["cgain"]) for x in d[a]]
        ys.append(np.mean(v)); es.append(np.std(v))
    ax.errorbar(fns, ys, yerr=es, color=c, marker="o", lw=2, capsize=3,
                label={"l2": "L2 (regression)", "mip": "MIP/Flow (generative)"}[a])
ax.axvline(0.005, color="gray", ls=":", lw=1)
ax.text(0.0053, 0.05, "showcase\noperating point", fontsize=8, color="gray")
ax.set_xlabel("force-sensor noise")
ax.set_ylabel("functional engagement |cancel-gain| (oracle = 1)")
ax.legend(fontsize=8.5)
ax.set_title("D. Why: the generative objective keeps the channel engaged at\n"
             "noise levels where the regression objective abandons it")

for a_ in axes.flat:
    a_.grid(alpha=0.25, lw=0.4)
fig.suptitle("Force toy, sensor noise 0.005: L2 half-abandons the force channel and fails under field-calibration drift;\n"
             "hetero/MIP/Flow objectives keep the feature engaged — and that alone converts to near-perfect deployment SR",
             y=0.995, fontsize=11)
fig.tight_layout(rect=(0, 0, 1, 0.955))
fig.savefig(OUT, dpi=150)
print("saved", OUT)
