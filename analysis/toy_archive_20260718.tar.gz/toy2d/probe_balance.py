"""Fixed-point balance: decompose the sensor-column gradient (first layer)
into in-strip and out-strip contributions at convergence, for l2 vs flow.
Also report them normalized by each objective's total gradient scale."""
import numpy as np
import torch

import toyattr as T

data, ob = T.build_dataset(None, data_seed=0)
X, Y, W = data
Xt = torch.tensor(X, device=T.DEV); Yt = torch.tensor(Y, device=T.DEV)
ins = np.where(W)[0]; outs = np.where(~W)[0]
dv = T.DIMV


def sensor_grad(net, loss_name, idx, rng, nb=48):
    W1 = net.f[0].weight
    acc = None
    for _ in range(nb):
        sub = idx[rng.randint(0, len(idx), 256)]
        xb, yb = Xt[sub], Yt[sub]
        if loss_name == "flow8":
            yn = (yb - net.ymu) / net.ysd
            eps = torch.randn_like(yn)
            tt = torch.rand(len(yn), 1, device=T.DEV)
            ytt = (1 - tt) * eps + tt * yn
            v = net.vel(xb, ytt, tt)
            l = ((v - (yn - eps)) ** 2).sum(dim=1).mean()
        else:
            pred, _ = net._fwd_norm(xb)
            ybn = (yb - net.yc) / net.ys
            l = ((pred - ybn) ** 2).sum(dim=1).mean()
        net.zero_grad(); l.backward()
        g = W1.grad.detach()[:, dv:dv + 2]
        acc = g.clone() if acc is None else acc + g
    return (acc / nb)


for arm in ("l2", "flow8"):
    net = T.train((data, ob), arm, seed=0, steps=12000)
    rng = np.random.RandomState(7)
    g_in = sensor_grad(net, arm, ins, rng)
    g_out = sensor_grad(net, arm, outs, rng)
    ni, no = float(g_in.norm()), float(g_out.norm())
    cos = float((g_in * g_out).sum() / (ni * no + 1e-12))
    print(f"{arm}: |sensor-grad| in-strip {ni:.4f} out-strip {no:.4f} | ratio in:out {ni/max(no,1e-9):.2f} | cos(in,out) {cos:+.2f}", flush=True)
