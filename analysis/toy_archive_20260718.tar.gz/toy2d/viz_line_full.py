"""Story figure for the tremor-free latent-line design. Top: the setting
(latent flip line; branch-vs-mean mechanism; table with cancellation grade).
Bottom: bars + per-policy counterfactual minis. Run with the line env:
FLINE=1 WLINE=0.06 TREMOR=0 EXNOISE=0.02 FNOISE=0.01 NORMIO."""
import json
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

import toyattr as T

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "money_full.png")

ARMS = ["l2", "ht", "hg", "mip", "flow8"]
NAME = {"l2": "L2 (MSE)", "ht": "hetero-t", "hg": "hetero-G", "mip": "MIP", "flow8": "Flow"}
COL = {"l2": "#d62728", "ht": "#9467bd", "hg": "#ff9896", "mip": "#1f77b4", "flow8": "#17becf"}
R = {a: json.load(open(os.path.join(HERE, "line_final.json")))[a] for a in ARMS}
mean = lambda a, k: np.mean([c[k] for c in R[a]])
std = lambda a, k: np.std([c[k] for c in R[a]])

fig = plt.figure(figsize=(15.5, 10.8))
gs = fig.add_gridspec(2, 15, height_ratios=[0.95, 1.1], wspace=1.1, hspace=0.32)

# ---------------- A: the latent-line setting -------------------------------
axA = fig.add_subplot(gs[0, 0:5])
c_ep = 0.03
axA.axvspan(-T.WLINE, T.WLINE, color="tab:orange", alpha=0.15)
for cc in (-0.045, 0.0):
    axA.axvline(cc, color="#c00000", lw=1.0, ls=":", alpha=0.6)
axA.axvline(c_ep, color="#c00000", lw=2.5)
for yy in (-0.1, 0.25, 0.6):
    for xx in np.linspace(-0.3, 0.3, 11):
        if abs(xx - c_ep) > 0.02:
            f = T.FA * np.tanh((xx - c_ep) / T.LSOFT)
            axA.arrow(xx, yy, f * 1.5, 0, head_width=0.015, head_length=0.012,
                      color="#c00000" if f > 0 else "#1f4fc0", alpha=0.6, lw=0.5)
for x0, gx in ((-0.35, 0.18), (0.35, -0.15)):
    p = np.array([x0, 1.0]); g = np.array([gx, 0.0])
    tr = [p.copy()]
    for _ in range(60):
        f = np.array([T.FA * np.tanh((p[0] - c_ep) / T.LSOFT), 0.0])
        a = np.clip(0.25 * (g - p), -0.15, 0.15) - f
        p = p + a + f
        tr.append(p.copy())
        if np.linalg.norm(p - g) < 0.01:
            break
    tr = np.array(tr)
    axA.plot(tr[:, 0], tr[:, 1], color="tab:blue", lw=1.8, alpha=0.9)
    axA.plot(*g, "kx", ms=9, mew=2)
axA.text(-0.44, 0.96, "demos: no tremor; expert cancels via sensor", fontsize=8.5, color="tab:blue")
axA.text(-0.44, -0.27, "line moves in the strip each episode (the ONLY\nrandomness); only the sensor reveals the side",
         fontsize=8.5, color="#c00000")
axA.set_xlim(-0.46, 0.46); axA.set_ylim(-0.3, 1.05)
axA.set_xticks([]); axA.set_yticks([])
axA.set_title("A. Reach + hold; the force flips across\na line that moves each episode (latent)", fontsize=10.5)

# ---------------- B: branch vs mean ----------------------------------------
axB = fig.add_subplot(gs[0, 5:10])
px = np.linspace(-0.14, 0.14, 400)
W = T.WLINE
pu = np.clip((px + W) / (2 * W), 0, 1)
ramp = T.FA * (2 * pu - 1)
axB.fill_between(px, T.FA - 0.004, T.FA + 0.004, where=px > -W, color="#c00000", alpha=0.55)
axB.fill_between(px, -T.FA - 0.004, -T.FA + 0.004, where=px < W, color="#1f4fc0", alpha=0.55)
axB.plot(px, ramp, "k--", lw=2, label="conditional mean  E[f | position]")
axB.annotate("branch +A (line was left of you)", (0.02, T.FA + 0.008), fontsize=8.5, color="#c00000")
axB.annotate("branch -A (line was right of you)", (-0.135, -T.FA + 0.008), fontsize=8.5, color="#1f4fc0")
axB.axvspan(-W, W, color="tab:orange", alpha=0.12)
axB.text(0, -0.070, "inside the strip: BOTH branches possible given position — bimodal label", ha="center", fontsize=8.2)
axB.set_xlabel("position $p_x$", fontsize=10)
axB.set_ylabel("force $f_x$", fontsize=10)
axB.set_ylim(-0.075, 0.075)
axB.legend(fontsize=8.5, loc="upper left")
axB.set_title("B. MSE can only fit the dashed ramp;\nthe branch requires the sensor", fontsize=10.5)

# ---------------- table -----------------------------------------------------
axT = fig.add_subplot(gs[0, 10:15])
axT.axis("off")
rows, rcolors = [], []
for a in ARMS:
    rows.append([NAME[a], f"{mean(a,'F_share'):.0%}",
                 f"{abs(mean(a,'cgain')):.2f}", f"{mean(a,'normal'):.2f}", f"{mean(a,'shift0.02'):.2f}"])
    rcolors.append(COL[a])
tbl = axT.table(cellText=rows,
                colLabels=["method", "force\nreliance", "cancel grade\n(oracle 1.0)", "SR\n(train)", "SR\n(drift)"],
                loc="center", cellLoc="center", bbox=[0, 0.05, 1, 0.85])
tbl.auto_set_font_size(False)
tbl.set_fontsize(10)
for k in range(5):
    tbl[0, k].set_facecolor("0.92"); tbl[0, k].set_height(0.18)
for r_ in range(1, len(rows) + 1):
    tbl[r_, 0].get_text().set_color(rcolors[r_ - 1])
    tbl[r_, 0].get_text().set_fontweight("bold")
    if ARMS[r_ - 1] == "l2":
        for k in range(5):
            tbl[r_, k].set_facecolor("#fdeaea")
axT.set_title("MSE cancel grade capped\nnear the ramp (~0.4)", fontsize=10.5)
axT.text(0.5, -0.02, "cap survives: 20x steps, 8x width, Muon, LR/SGD/\nschedule/batch sweeps, wd<=1e-3. wd>=3e-3 reallocates\nbut breaks the policy. Muon drags Flow back to the cap.",
         transform=axT.transAxes, ha="center", va="top", fontsize=8.2, color="0.25")

# ---------------- C: bars ---------------------------------------------------
ax = fig.add_subplot(gs[1, 0:6])
x = np.arange(len(ARMS)); w = 0.38
idv = [mean(a, "normal") for a in ARMS]
drv = [mean(a, "shift0.02") for a in ARMS]
dsd = [std(a, "shift0.02") for a in ARMS]
ax.bar(x - w / 2, idv, w, color="0.6", label="training conditions")
ax.bar(x + w / 2, drv, w, color=[COL[a] for a in ARMS], yerr=dsd,
       error_kw=dict(lw=1, capsize=3), label="deployment (field drifted)")
for i in range(len(ARMS)):
    ax.text(x[i] + w / 2, drv[i] + 0.035, f"{drv[i]:.2f}", ha="center", fontsize=12, fontweight="bold")
ax.set_xticks(x); ax.set_xticklabels([NAME[a] for a in ARMS], fontsize=10.5)
ax.set_ylabel("success rate", fontsize=12)
ax.set_ylim(0, 1.18)
ax.legend(fontsize=10, loc="lower right")
ax.set_title("C. Zero label noise anywhere: the gap is pure objective structure", fontsize=11.5)
ax.grid(alpha=0.25, lw=0.4, axis="y")

# ---------------- D: cancel-grade -> deployment scatter --------------------
axD = fig.add_subplot(gs[1, 7:14])
for a in ARMS:
    xs = [abs(c["cgain"]) for c in R[a]]
    ys = [c["shift0.02"] for c in R[a]]
    axD.scatter(xs, ys, s=55, color=COL[a], label=NAME[a], edgecolor="white", linewidth=0.6)
axD.axvspan(0.30, 0.45, color="0.9", zorder=0)
axD.axvline(0.60, color="0.4", lw=1.2, ls="--")
axD.text(0.605, 0.03, "payoff\nthreshold", fontsize=8, color="0.35")
SCR = "/tmp/claude-1001/-home-jigu-projects-much-ado-about-noising/469964b2-9364-47f5-8a44-7dda4fc11f85/scratchpad"
def _cell(path, arm="l2"):
    import json as _j
    try:
        c = _j.load(open(path))[arm]
        return (abs(np.mean([x["cgain"] for x in c])), np.mean([x["shift0.02"] for x in c]))
    except Exception:
        return None
tuned = [p for p in [
    _cell(f"{SCR}/tune_lr3e-3.json"), _cell(f"{SCR}/tune_lr1e-2.json"),
    _cell(f"{SCR}/tune_lr3e-4.json"), _cell(f"{SCR}/tune_sgdm.json"),
    _cell(f"{SCR}/tune_cos24k.json"), _cell(f"{SCR}/tune_batch64.json"),
    _cell(f"{SCR}/tune_batch1024.json"), _cell(f"{SCR}/l2_240k.json"),
    _cell(f"{SCR}/line_w128.json"), _cell(f"{SCR}/line_w256.json"),
    _cell(f"{SCR}/line_muon.json")] if p]
wds = [p for p in [_cell(f"{SCR}/wd_1e-4.json"), _cell(f"{SCR}/wd_3e-4.json"),
                   _cell(f"{SCR}/wd_1e-3.json"), _cell(f"{SCR}/wd_3e-3.json"),
                   _cell(f"{SCR}/tune_adamw.json")] if p]
fm = _cell(f"{SCR}/line_muon.json", "flow8")
axD.scatter([t[0] for t in tuned], [t[1] for t in tuned], marker="^", s=48,
            facecolors="none", edgecolors="#d62728", linewidths=1.2,
            label="L2 tuned (LR/SGD/sched/batch/width/240k/Muon)")
axD.plot([w[0] for w in wds], [w[1] for w in wds], "D-", ms=6, color="#8c564b",
         mfc="none", lw=1, label="L2 + weight decay (rising wd; policy breaks past 0.54)")
if fm:
    axD.scatter([fm[0]], [fm[1]], marker="*", s=180, color="#17becf", edgecolor="k",
                linewidths=0.8, label="Flow + Muon (advantage destroyed)")
axD.text(0.375, 1.02, "the mean-grade cap\n(the ramp, ~0.4)", ha="center", fontsize=9, color="0.35")
axD.set_xlabel("cancellation grade  |dcancel/dsensor|  (oracle = 1.0)", fontsize=11)
axD.set_ylabel("deployment SR (drifted field)", fontsize=11)
axD.set_xlim(0.15, 0.85); axD.set_ylim(-0.05, 1.1)
axD.legend(fontsize=9.5, loc="upper left")
axD.grid(alpha=0.25, lw=0.4)
axD.set_title("D. Every experiment on one plane: no tuned MSE crosses the payoff\n"
              "threshold; generative seeds cross it under Adam; Muon drags Flow back", fontsize=11.5)

fig.suptitle("Latent-line toy, ZERO label noise: MSE uses the force sensor only at mean grade (fits the ramp; capped ~0.4) —\n"
             "generative objectives (MIP/Flow) resolve the latent branch through the sensor and survive deployment  [IO min-max normalized]",
             fontsize=12.5, y=0.995)
fig.savefig(OUT, dpi=150, bbox_inches="tight")
print("saved", OUT)
