"""Settle-collapse config: approach -> hold K steps at g1 (obs-identical,
timing unobservable) -> stroke to g2 (in obs; random side). The settle set is
measure-thin with time-bimodal labels; conditional-mean objectives should
TRANSLATE at settle; generative samplers should emit coherent hold/go chunks.
Measures: settle drift speed, SR (clean hold >= KMIN then reach g2)."""
import numpy as np
import torch

import toyattr as T

K_HOLD = int(T._os.environ.get("KHOLD", "20"))
KMIN = int(T._os.environ.get("KMIN", "12"))
np.random.seed(0)


class SettleObs:
    def __init__(self, seed=123):
        r = np.random.RandomState(seed)
        self.Wp = r.randn(6, 2) / np.sqrt(2)
        self.W1 = r.randn(4, 2) / np.sqrt(2)
        self.W2 = r.randn(4, 2) / np.sqrt(2)

    def obs(self, p, g1, g2, clock, rng):
        v = np.concatenate([self.Wp @ p, self.W1 @ g1, self.W2 @ g2]) + 0.005 * rng.randn(14)
        c = np.array([clock]) + float(T._os.environ.get("CLKN", "0.002")) * rng.randn(1)
        return np.concatenate([v, c]).astype(np.float32)


def gen_episode(rng):
    g1 = rng.uniform([-0.2, -0.2], [0.2, 0.2])
    g2 = g1 + np.array([rng.choice([-1, 1]) * rng.uniform(0.3, 0.45), 0.0])
    p = g1 + np.array([rng.uniform(-0.04, 0.04), 0.9])
    ps, acts, cks = [], [], []
    khold = 0
    ex = float(T._os.environ.get("EXNOISE", "0.01"))
    for _ in range(220):
        clock = float(T._os.environ.get("CLKA", "0.05")) * (0.98 ** khold)
        cks.append(clock)
        if khold < K_HOLD:
            if np.linalg.norm(p - g1) < 0.03:
                khold += 1
                a = np.zeros(2)
            else:
                a = np.clip(0.25 * (g1 - p), -0.15, 0.15)
        else:
            a = np.clip(0.25 * (g2 - p), -0.15, 0.15)
        ps.append(p.copy()); acts.append(a.copy())
        p = p + a + ex * rng.randn(2)
        if khold >= K_HOLD and np.linalg.norm(p - g2) < 0.03:
            break
    return np.array(ps), np.array(acts), np.array(cks), g1, g2


def build(n_ep=150):
    rng = np.random.RandomState(0)
    ob = SettleObs()
    X, Y, W = [], [], []
    for _ in range(n_ep):
        ps, acts, cks, g1, g2 = gen_episode(rng)
        obs = np.array([ob.obs(p, g1, g2, c, rng) for p, c in zip(ps, cks)])
        near = np.array([np.linalg.norm(p - g1) < 0.05 for p in ps])
        for t in range(len(ps) - T.H):
            X.append(obs[t]); Y.append(acts[t:t + T.H].reshape(-1)); W.append(near[t])
    return (np.array(X, dtype=np.float32), np.array(Y, dtype=np.float32), np.array(W)), ob


def evaluate(net, ob, n_ep=100, seed=999, AS=8):
    rng = np.random.RandomState(seed)
    succ, drifts = 0, []
    for _ in range(n_ep):
        g1 = rng.uniform([-0.2, -0.2], [0.2, 0.2])
        g2 = g1 + np.array([rng.choice([-1, 1]) * rng.uniform(0.3, 0.45), 0.0])
        p = g1 + np.array([rng.uniform(-0.04, 0.04), 0.9])
        khold, ok, arrived = 0, False, False
        drift_speeds = []
        for step in range(0, 300, AS):
            clock = float(T._os.environ.get("CLKA", "0.05")) * (0.98 ** khold)
            o = torch.tensor(ob.obs(p, g1, g2, clock, rng)[None], device=T.DEV)
            with torch.no_grad():
                chunk = net(o)[0].reshape(T.H, 2).cpu().numpy()
            aborted = False
            for a in chunk[:AS]:
                inhold = np.linalg.norm(p - g1) < 0.03 and khold < K_HOLD
                clock = float(T._os.environ.get("CLKA", "0.05")) * (0.98 ** khold)
                if khold > 0 and khold < K_HOLD and abs(p[0] - g1[0]) > float(T._os.environ.get("SLOT", "1.0")):
                    aborted = True
                    break
                if inhold:
                    khold += 1
                    drift_speeds.append(abs(a[0]))
                p = p + np.clip(a, -0.15, 0.15)
                if khold >= KMIN and np.linalg.norm(p - g2) < 0.03:
                    ok = True; break
            if ok or aborted:
                break
        succ += int(ok)
        if drift_speeds:
            drifts.append(np.mean(drift_speeds))
    return succ / n_ep, (float(np.mean(drifts)) if drifts else float("nan"))


if __name__ == "__main__":
    data, ob = build()
    X, Y, W = data
    print(f"dataset {len(X)} samples, near-settle frac {W.mean():.2f}", flush=True)
    for arm in ("l2", "mip", "flow8"):
        for seed in (0, 1):
            net = T.train(((X, Y, W), ob), arm, seed=seed, steps=12000)
            sr8, dr8 = evaluate(net, ob, AS=8)
            sr1, dr1 = evaluate(net, ob, AS=1)
            print(f"{arm} s{seed}: SR AS8/AS1 = {sr8:.2f}/{sr1:.2f} | settle drift-speed AS8/AS1 = {dr8:.4f}/{dr1:.4f}", flush=True)
