"""Three probes on the tremor-free latent line:
(1) hetero sigma trajectory (in/out-strip) — degeneracy diagnosis;
(2) l2 long-training cancel-grade — structural cap vs convergence-rate;
(3) flow t-binned force/pos gradient signal — where the branch pressure lives."""
import numpy as np
import torch

import toyattr as T

data, ob = T.build_dataset(None, data_seed=0)
X, Y, W = data
Xt = torch.tensor(X, device=T.DEV); Yt = torch.tensor(Y, device=T.DEV)
instrip = torch.tensor(np.abs(X[:, 0] * 0 + 1) > 0)  # placeholder
# in-strip indicator from raw px: obs are normalized inside net; use W (near-line mask from build)
ins = torch.tensor(W, device=T.DEV)


def cancel_gain(net):
    xs = torch.tensor(X[W][:256], device=T.DEV, requires_grad=True)
    a1x = net.chunk_from_obs(xs)[:, 0]
    g = torch.autograd.grad(a1x.sum(), xs)[0]
    return float(g[:, 12].mean())


# ---- (1) hetero sigma trajectory ----
for loss in ("ht", "hg"):
    torch.manual_seed(0)
    net = T.Net(X.shape[1], dim_v=T.DIMV).to(T.DEV)
    net.set_norm(X.min(0), X.max(0), Y.min(0), Y.max(0))
    opt = torch.optim.Adam(net.parameters(), lr=1e-3)
    rng = np.random.RandomState(0)
    for it in range(1, 12001):
        idx = rng.randint(0, len(Xt), 256)
        xb, yb = Xt[idx], Yt[idx]
        pred, sraw = net._fwd_norm(xb)
        ybn = (yb - net.yc) / net.ys
        r2 = ((pred - ybn) ** 2).sum(dim=1)
        sig = torch.nn.functional.softplus(sraw) + T.SIGFLOOR
        if loss == "hg":
            l = (0.5 * r2 / sig ** 2 + (2 * T.H) * torch.log(sig)).mean()
        else:
            nu = 3.0
            z2 = r2 / (sig ** 2 * (2 * T.H))
            l = (0.5 * (nu + 2 * T.H) * torch.log1p(z2 * (2 * T.H) / nu) + (2 * T.H) * torch.log(sig)).mean()
        opt.zero_grad(); l.backward(); opt.step()
        if it in (500, 2000, 6000, 12000):
            with torch.no_grad():
                _, sr = net._fwd_norm(Xt)
                sg = torch.nn.functional.softplus(sr) + T.SIGFLOOR
                w_in = (1 / sg[ins] ** 2).mean().item(); w_out = (1 / sg[~ins] ** 2).mean().item()
            print(f"{loss} @{it:5d}: sigma in/out-strip {sg[ins].mean():.4f}/{sg[~ins].mean():.4f} "
                  f"| weight(1/sig^2) in/out {w_in:.0f}/{w_out:.0f} | ratio out:in {w_out/max(w_in,1e-9):.1f} "
                  f"| cgain {cancel_gain(net):+.2f}", flush=True)

# ---- (2) l2 long training ----
torch.manual_seed(0)
net = T.Net(X.shape[1], dim_v=T.DIMV).to(T.DEV)
net.set_norm(X.min(0), X.max(0), Y.min(0), Y.max(0))
opt = torch.optim.Adam(net.parameters(), lr=1e-3)
rng = np.random.RandomState(0)
for it in range(1, 60001):
    idx = rng.randint(0, len(Xt), 256)
    xb, yb = Xt[idx], Yt[idx]
    pred, _ = net._fwd_norm(xb)
    ybn = (yb - net.yc) / net.ys
    l = ((pred - ybn) ** 2).sum(dim=1).mean()
    opt.zero_grad(); l.backward(); opt.step()
    if it in (6000, 12000, 24000, 48000, 60000):
        print(f"l2-long @{it:5d}: cgain {cancel_gain(net):+.2f}", flush=True)

# ---- (3) flow t-binned gradient signal ----
torch.manual_seed(0)
net = T.MipNet(X.shape[1]).to(T.DEV)
net.nsteps = 8
net.set_norm(X.min(0), X.max(0), Y.min(0), Y.max(0))
net.ymu.copy_(Yt.mean(0)); net.ysd.copy_(Yt.std(0) + 1e-6)
opt = torch.optim.Adam(net.parameters(), lr=1e-3)
rng = np.random.RandomState(0)
for phase, upto in (("2k", 2000), ("12k", 12000)):
    while True:
        it = getattr(net, "_it", 0)
        if it >= upto:
            break
        idx = rng.randint(0, len(Xt), 256)
        xb, yb = Xt[idx], Yt[idx]
        yn = (yb - net.ymu) / net.ysd
        eps = torch.randn_like(yn)
        tt = torch.rand(len(yn), 1, device=T.DEV)
        ytt = (1 - tt) * eps + tt * yn
        v = net.vel(xb, ytt, tt)
        l = ((v - (yn - eps)) ** 2).sum(dim=1).mean()
        opt.zero_grad(); l.backward(); opt.step()
        net._it = it + 1
    W1 = net.f[0].weight
    dv = T.DIMV
    for lo, hi in ((0.0, 0.25), (0.25, 0.5), (0.5, 0.75), (0.75, 1.0)):
        grads = []
        for _ in range(48):
            idx = rng.randint(0, len(Xt), 256)
            xb, yb = Xt[idx], Yt[idx]
            yn = (yb - net.ymu) / net.ysd
            eps = torch.randn_like(yn)
            tt = lo + (hi - lo) * torch.rand(len(yn), 1, device=T.DEV)
            ytt = (1 - tt) * eps + tt * yn
            v = net.vel(xb, ytt, tt)
            l = ((v - (yn - eps)) ** 2).sum(dim=1).mean()
            opt.zero_grad(); l.backward()
            grads.append(W1.grad.detach()[:, :dv + 2].clone())
        G = torch.stack(grads)
        gm = G.mean(0)
        fsig = float(gm[:, dv:dv + 2].norm()); psig = float(gm[:, :dv].norm())
        print(f"flow@{phase} t=[{lo:.2f},{hi:.2f}): force-grad {fsig:.4f} pos-grad {psig:.4f} "
              f"force share {fsig/(fsig+psig):.2f}", flush=True)
