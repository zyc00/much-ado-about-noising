"""Visualize the redun (tactile-analog) TASK itself: geometry, the two
redundant observation channels, the geometry of vision miscalibration, and
trained-policy endgame rollouts under corruption."""
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

import toyattr as T

assert T.CONFIG == "redun", "run with TOYCFG=redun"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "redun_task_viz.png")


def rollout_traj(net, ob, g, delta, seed, ood=None, AS=8, nsteps=200):
    rng = np.random.RandomState(seed)
    p = np.array([0.0, 1.4]) + 0.05 * rng.randn(2)
    traj = [p.copy()]
    for step in range(0, nsteps, AS):
        o = torch.tensor(ob.obs(p, g, delta, rng, ood)[None], device=T.DEV)
        with torch.no_grad():
            chunk = net(o)[0].reshape(T.H, 2).cpu().numpy()
        for a in chunk[:AS]:
            p = p + np.clip(a, -T.VMAX, T.VMAX)
            traj.append(p.copy())
    return np.array(traj)


fig, axes = plt.subplots(2, 2, figsize=(13, 11))

# --- A: task geometry -------------------------------------------------------
ax = axes[0, 0]
for s in range(8):
    rng = np.random.RandomState(s)
    ps, acts, g, delta = T.make_episode(rng, None)
    (ln,) = ax.plot(ps[:, 0], ps[:, 1], lw=1.0, alpha=0.8)
    c = ln.get_color()
    ax.plot(*g, "o", color=c, ms=5, mfc="none")
    ax.plot(*(g + delta), "x", color=c, ms=6)
ax.add_patch(plt.Rectangle((-0.3, -0.3), 0.6, 0.6, fill=False, ls=":", color="gray"))
ax.plot([], [], "ko", mfc="none", label="goal g")
ax.plot([], [], "kx", label="true target g+$\\delta$")
ax.scatter([0.0], [1.4], marker="s", c="k", s=30, label="start")
ax.set_title("A. Same task as before: reach from the start, then settle and\n"
             "hold within tol 0.02 of g+$\\delta$ (tremor 0.02·t(3) in demos)")
ax.legend(loc="lower right", fontsize=8)
ax.set_aspect("equal")

# --- B: the two redundant channels along one episode ------------------------
ax = axes[0, 1]
ob = T.RedunObs(seed=123)
rng = np.random.RandomState(11)
ps, acts, g, delta = T.make_episode(rng, None)
obs = np.array([ob.obs(p, g, delta, rng) for p in ps])
resid = np.linalg.norm((g + delta) - ps, axis=1)
dist = np.linalg.norm(ps - g, axis=1)
tt = np.arange(len(ps))
ax.plot(tt, resid, "k-", lw=1.8, label="true residual $|g+\\delta-p|$")
ax.plot(tt, np.linalg.norm(obs[:, 12:16], axis=1) / 4.0, color="tab:red", lw=1.2,
        label="V-fine channel $\\tanh(4W_f r)$ (scaled) — vision sees the residual")
ax.plot(tt, np.linalg.norm(obs[:, 16:18], axis=1), color="tab:orange", lw=1.2,
        label="$\\|T\\|$ — tactile sees the SAME residual (gated, noisier)")
on = np.argmax(dist < T.RNEAR)
ax.axvline(on, color="tab:orange", ls=":", lw=1)
ax.text(on + 1, 0.5, "T gate opens", fontsize=8, color="tab:orange")
ax.set_yscale("log"); ax.set_ylim(3e-3, 2.5)
ax.set_xlabel("episode step")
ax.set_title("B. The redundancy: BOTH channels track the same residual on the\n"
             "training support — vision is cleaner (0.005 vs 0.01 noise), so\n"
             "a monolithic policy has no reason to keep T")
ax.legend(fontsize=8, loc="upper right")

# --- C: geometry of the corruption -----------------------------------------
ax = axes[1, 0]
gg = np.array([0.0, 0.0]); dd = np.array([0.05, 0.03])
bdir = np.array([1.0, -0.35]); bdir /= np.linalg.norm(bdir)
tgt = gg + dd
ax.plot(*gg, "o", color="k", mfc="none", ms=9)
ax.annotate("g (goal)", gg, xytext=(gg[0] - 0.045, gg[1] - 0.012), fontsize=9)
ax.annotate("", xy=tgt, xytext=gg, arrowprops=dict(arrowstyle="->", color="k", lw=1.2))
ax.plot(*tgt, "kx", ms=10)
ax.annotate("true target g+$\\delta$\n(T reports this)", tgt, xytext=(tgt[0] - 0.085, tgt[1] + 0.028),
            fontsize=9)
ax.add_patch(plt.Circle(tgt, T.TOL, fill=False, color="tab:green", lw=1.6))
ax.annotate("success region (tol 0.02)", (tgt[0] - 0.016, tgt[1] + 0.016), xytext=(tgt[0] - 0.095, tgt[1] + 0.042),
            fontsize=8, color="tab:green", arrowprops=dict(arrowstyle="-", color="tab:green", lw=0.7))
for b, cc in [(0.02, "#ffb000"), (0.04, "#e05d00"), (0.08, "#c00000")]:
    fp = tgt + b * bdir
    ax.plot(*fp, "s", color=cc, ms=7)
    ax.annotate(f"b={b:g}", fp, xytext=(fp[0] + 0.006, fp[1] + 0.006), fontsize=8, color=cc)
ax.annotate("", xy=tgt + 0.08 * bdir, xytext=tgt,
            arrowprops=dict(arrowstyle="->", color="#c00000", lw=1.2, ls="--"))
ax.text(0.055, -0.045,
        "miscalibrated vision reports r+b, so a V-committed\n"
        "servo settles at g+$\\delta$+b — outside tol once b > 0.02", fontsize=8, color="#c00000")
ax.set_xlim(-0.10, 0.17); ax.set_ylim(-0.062, 0.095)
ax.set_aspect("equal")
ax.set_title("C. What deployment corruption does: bias b moves the fixed point\n"
             "of a vision-committed servo; the T channel still points at the truth")

# --- D: trained policies under bias 0.04 -----------------------------------
ax = axes[1, 1]
data, ob2 = T.build_dataset(None, data_seed=0)
nets = {}
for name in ("l2", "gdrop", "tonly"):
    nets[name] = T.train((data, ob2), name, seed=0, steps=12000)
rngG = np.random.RandomState(41)
g = rngG.uniform([-0.3, -0.3], [0.3, 0.3])
delta = rngG.uniform(0.03, 0.08) * T._unit(rngG)
tgt = g + delta
bvec = 0.04 * np.array([0.8, 0.6])
ood = {"kind": "bias", "vec": bvec}
cols = {"l2": "#d62728", "gdrop": "#2ca02c", "tonly": "#17becf"}
lbls = {"l2": "L2 (V-committed)", "gdrop": "V-dropout (keeps T)", "tonly": "T-only (oracle)"}
for name in ("l2", "gdrop", "tonly"):
    for s in range(5):
        traj = rollout_traj(nets[name], ob, g, delta, seed=300 + s, ood=ood)
        ax.plot(traj[:, 0], traj[:, 1], color=cols[name], lw=0.9, alpha=0.7,
                label=lbls[name] if s == 0 else None)
ax.add_patch(plt.Circle(tgt, T.TOL, fill=False, color="k", lw=1.4))
ax.plot(*tgt, "kx", ms=9)
ax.plot(*(tgt + bvec), "s", color="#c00000", ms=7)
ax.annotate("true target\n(+ tol circle)", tgt, xytext=(tgt[0] - 0.075, tgt[1] - 0.045), fontsize=8)
ax.annotate("vision-implied\nfixed point (b=0.04)", tgt + bvec,
            xytext=(tgt[0] + bvec[0] + 0.008, tgt[1] + bvec[1] - 0.02), fontsize=8, color="#c00000")
m = 0.12
ax.set_xlim(tgt[0] - m, tgt[0] + m); ax.set_ylim(tgt[1] - m, tgt[1] + m)
ax.legend(loc="upper left", fontsize=8)
ax.set_aspect("equal")
ax.set_title("D. Trained policies under bias 0.04 (endgame zoom, 5 rollouts each):\n"
             "L2 settles at the vision-implied point and misses; T-keeping\n"
             "policies settle on the true target")

for a_ in axes.flat:
    a_.grid(alpha=0.25, lw=0.4)
fig.suptitle("Config redun — the tactile-analog task: vision fully explains the demos, tactile is a noisier duplicate;\n"
             "at deployment only vision is corrupted, so success depends on whether training kept the tactile channel engaged",
             y=0.998, fontsize=11)
fig.tight_layout(rect=(0, 0, 1, 0.965))
fig.savefig(OUT, dpi=150)
print("saved", OUT)
