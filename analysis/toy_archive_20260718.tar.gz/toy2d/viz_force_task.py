"""Visualize the force config: field geometry, the tube-vs-sensor economics,
behavioral capture evidence, and rollouts under field-calibration shift."""
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

import toyattr as T

assert T.CONFIG == "force"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "force_task_viz.png")

fig, axes = plt.subplots(2, 2, figsize=(13.5, 11))

# --- A: task + field geometry ----------------------------------------------
ax = axes[0, 0]
g = np.array([0.05, -0.1])
xs = np.linspace(g[0] - T.RF, g[0] + T.RF, 23)
ys = np.linspace(g[1] - T.RF, g[1] + T.RF, 23)
for xx in xs[::2]:
    for yy in ys[::2]:
        p = np.array([xx, yy])
        f = T.field(p, g, np.zeros(2))
        if np.abs(f).sum() > 0:
            ax.arrow(xx, yy, f[0] * 0.8, f[1] * 0.8, head_width=0.006,
                     color="tab:red", alpha=0.55, lw=0.5)
for s in range(4):
    rng = np.random.RandomState(s + 20)
    out = T.make_episode(rng, None)
    ps = out[0]; gg = out[2]
    sel = np.linalg.norm(ps - g, axis=1) < 1.8
    ax.plot(ps[:, 0] - gg[0] + g[0], ps[:, 1] - gg[1] + g[1], lw=0.9, alpha=0.8,
            color="tab:blue")
ax.add_patch(plt.Circle(g, T.RF, fill=False, ls="--", color="gray", lw=1.2))
ax.plot(*g, "kx", ms=10)
ax.annotate("goal g (target: hold within tol)", g, xytext=(g[0] - 0.22, g[1] - 0.045), fontsize=8)
ax.annotate("force area (|p-g| < 0.25):\nfield pushes in x, demonstrator\ncancels it (reads the sensor)",
            (g[0] + 0.08, g[1] + 0.19), fontsize=8, color="tab:red")
ax.set_xlim(g[0] - 0.32, g[0] + 0.32); ax.set_ylim(g[1] - 0.3, g[1] + 0.34)
ax.set_aspect("equal")
ax.set_title("A. The task: reach + hold at g while a real force field acts.\n"
             "Demos (blue) look straight because the expert cancels the force")

# --- B: the economics — field profile vs demo tube + shift ------------------
ax = axes[0, 1]
dx = np.linspace(-0.25, 0.25, 400)
fx = T.FA * (np.sin(T.FW * dx) + T.FC)
ax.plot(dx, fx, "k-", lw=1.8, label="field profile $f_x(p_x-g_x)$ (training)")
ax.plot(dx, fx + 0.02, "r--", lw=1.5, label="deployed field (calibration shift +0.02)")
# demo-visited band: collect px-gx from episodes
rng = np.random.RandomState(0)
band = []
for _ in range(30):
    out = T.make_episode(rng, None)
    ps, gg = out[0], out[2]
    infield = np.linalg.norm(ps - gg, axis=1) < T.RF
    band += list((ps[infield, 0] - gg[0]))
lo, hi = np.percentile(band, [5, 95])
ax.axvspan(lo, hi, color="tab:blue", alpha=0.15)
ax.text((lo + hi) / 2, ax.get_ylim()[0] + 0.005, "demo tube\n(90% of visited $p_x-g_x$)",
        ha="center", fontsize=8, color="tab:blue")
ax.axhline(0, color="gray", lw=0.5)
ax.set_xlabel("$p_x - g_x$")
ax.set_ylabel("applied force $f_x$")
ax.legend(fontsize=8, loc="upper left")
ax.set_title("B. Two routes to the same value: position must LEARN this curve\n"
             "(from the tube band only); the sensor READS it — anywhere, and\n"
             "still-correct when the field shifts at deployment")

# --- C: behavioral capture evidence (probe data, operating point) -----------
ax = axes[1, 0]
conds = ["normal", "sensor=0", "scrambled", "shift 0.02", "shift 0.04"]
l2v = np.array([[0.97, 1.00], [1.00, 0.37], [0.96, 0.03], [0.00, 0.00], [0.00, 0.00]])
pdv = np.array([[0.99, 1.00], [0.00, 0.00], [0.00, 0.00], [0.91, 0.54], [0.48, 0.19]])
x = np.arange(len(conds)); w = 0.35
ax.bar(x - w / 2, l2v.mean(1), w, color="#d62728", label="L2 (F-share 0.04-0.06)")
ax.bar(x + w / 2, pdv.mean(1), w, color="#2ca02c", label="pdropf 0.9 (F-share 0.62-0.72)")
for i in range(len(conds)):
    ax.plot([x[i] - w / 2] * 2, l2v[i], "ko", ms=3)
    ax.plot([x[i] + w / 2] * 2, pdv[i], "ko", ms=3)
ax.set_xticks(x); ax.set_xticklabels(conds, fontsize=9)
ax.set_ylabel("success rate (AS=1, eval tol 0.045)")
ax.legend(fontsize=8)
ax.set_title("C. Behavioral evidence (2 seeds, dots): L2 is sensor-invariant\n"
             "(ignores force) and dies under shift; the dropout cure depends on\n"
             "the sensor and survives the shift")

# --- D: rollouts under shift 0.02 ------------------------------------------
ax = axes[1, 1]
data, ob = T.build_dataset(None, data_seed=0)
import os as _o
_o.environ["PDROP"] = "0.9"
nets = {a: T.train((data, ob), a, seed=0, steps=12000) for a in ("l2", "pdropf")}
gg = np.array([0.1, -0.05])
sv = np.array([0.02, 0.0])
cols = {"l2": "#d62728", "pdropf": "#2ca02c"}
for name, net in nets.items():
    for s in range(5):
        rng = np.random.RandomState(400 + s)
        p = np.array([0.0, 1.4]) + 0.05 * rng.randn(2)
        traj = [p.copy()]
        for step in range(200):
            f_app = T.field(p, gg, np.zeros(2)) + (sv if np.linalg.norm(p - gg) < T.RF else 0.0)
            o = torch.tensor(ob.obs(p, gg, np.zeros(2), rng, None, f=f_app)[None], device=T.DEV)
            with torch.no_grad():
                a = net(o)[0].reshape(T.H, 2).cpu().numpy()[0]
            p = p + np.clip(a, -T.DCLIP, T.DCLIP) + f_app
            traj.append(p.copy())
        traj = np.array(traj)
        ax.plot(traj[:, 0], traj[:, 1], color=cols[name], lw=0.9, alpha=0.7,
                label={"l2": "L2", "pdropf": "pdropf 0.9"}[name] if s == 0 else None)
ax.add_patch(plt.Circle(gg, 0.045, fill=False, color="k", lw=1.3))
ax.add_patch(plt.Circle(gg, T.RF, fill=False, ls="--", color="gray", lw=0.8))
ax.plot(*gg, "kx", ms=9)
ax.annotate("g (+ eval tol 0.045)", gg, xytext=(gg[0] - 0.16, gg[1] - 0.09), fontsize=8)
m = 0.2
ax.set_xlim(gg[0] - m, gg[0] + m); ax.set_ylim(gg[1] - m, gg[1] + m)
ax.legend(loc="upper left", fontsize=8)
ax.set_aspect("equal")
ax.set_title("D. Deployment (field shifted +0.02, sensor truthful): L2 cancels\n"
             "the memorized field and parks off-target; the sensor-reliant\n"
             "policy cancels the true force and holds")

for a_ in axes.flat:
    a_.grid(alpha=0.25, lw=0.4)
fig.suptitle("Config force — a real force acts on the point; on the demos the field is position-predictable, so MSE\n"
             "internalizes it from position and ignores the sensor; when the field's calibration drifts, only sensor-reliant policies survive",
             y=0.995, fontsize=11)
fig.tight_layout(rect=(0, 0, 1, 0.955))
fig.savefig(OUT, dpi=150)
print("saved", OUT)
