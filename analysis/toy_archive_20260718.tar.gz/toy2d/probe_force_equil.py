"""Equilibrium map: net x-displacement D(x) = a_x(x) + f_shifted(x) along a
sweep through the goal; park = zero crossing; stable iff -2 < slope < 0."""
import numpy as np
import torch

import toyattr as T

data, ob = T.build_dataset(None, data_seed=0)
g = np.array([0.0, 0.0])
xs = np.linspace(-0.12, 0.12, 121)
import os as _os
for arm, seed in [("mip", 9), ("mip", 1), ("pdropf", 0), ("l2", 0)]:
    if arm == "pdropf":
        _os.environ["PDROP"] = "0.9"
    net = T.train((data, ob), arm, seed=seed, steps=12000)
    rng = np.random.RandomState(3)
    D = []
    for x in xs:
        p = np.array([x, 0.0])
        f_app = T.field(p, g, np.zeros(2)) + np.array([0.02, 0.0])
        vals = []
        for _ in range(8):
            o = torch.tensor(ob.obs(p, g, np.zeros(2), rng, None, f=f_app)[None], device=T.DEV)
            with torch.no_grad():
                a = net(o)[0].reshape(T.H, 2).cpu().numpy()[0]
            vals.append(a[0])
        D.append(np.mean(vals) + f_app[0])
    D = np.array(D)
    zc = []
    for i in range(len(xs) - 1):
        if D[i] * D[i + 1] < 0:
            x0 = xs[i] - D[i] * (xs[i + 1] - xs[i]) / (D[i + 1] - D[i])
            sl = (D[i + 1] - D[i]) / (xs[i + 1] - xs[i])
            zc.append((x0, sl))
    desc = " ".join(f"x*={x0:+.3f}(slope {sl:+.1f}{'S' if -2 < sl < 0 else 'U'})" for x0, sl in zc) or "none in range"
    intol = any(abs(x0) < 0.045 and -2 < sl < 0 for x0, sl in zc)
    print(f"{arm} s{seed}: equilibria: {desc} | stable-in-tol: {intol}", flush=True)
